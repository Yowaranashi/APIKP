﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SQLlib;
namespace session1
{
    public partial class organizatorForm : Form
    {
        int organizationId;
        int idChemp;
        public organizatorForm(int id)
        {
            organizationId = id;
            InitializeComponent();
            loadChemp();
        }
        SQL database = new SQL();
        DateTime currValue = DateTime.Now.Subtract(new TimeSpan(30, 0, 0, 0));
        private void close_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void chempionat_Click(object sender, EventArgs e)
        {
          
            
            
            //content.DataSource = database.returnDataTable($"select * from competition where date_start >= '{currValue}'"); 
        }






        /// <summary>
        /// Загрузка чемпионатов в combobox
        /// </summary>
        private void loadChemp()
        {
            try
            {
                var dataTable = database.returnDataTable($"select id, title from competition where date_start >= '{currValue}'");

                foreach (DataRow row in dataTable.Rows)
                {
                    int id = (int)row.ItemArray[0];
                    string title = (string)row.ItemArray[1];

                    selectChemp.Items.Add(new KeyValuePair<int, string>(id, title));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"При выполнении запроса произошла ошибка {ex.Message}, обратитесь к специалисту");
            }
          

        }




        /// <summary>
        /// Открытие формы настройки чемпионата
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void settingChemp_Click(object sender, EventArgs e)
        {
            Visible = false;
            var settingChempForm = new settingChemp(organizationId, idChemp);
            settingChempForm.ShowDialog();
            Visible = true;

        }


        /// <summary>
        /// Вывод данных о выбранном чемпионате
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void selectChemp_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                idChemp = ((KeyValuePair<int, string>)selectChemp.SelectedItem).Key;
                string title = ((KeyValuePair<int, string>)selectChemp.SelectedItem).Value;

                var dateStart = database.ExecuteScalar<DateTime>($"select date_start from competition where id = {idChemp}");
                var dateEnd = database.ExecuteScalar<DateTime>($"select date_end from competition where id = {idChemp}");

                name.Text = title;
                start.Value = dateStart;
                end.Value = dateEnd;

                var dataTable = database.returnDataTable($"exec getSkillsById {idChemp}");

                foreach (DataRow row in dataTable.Rows)
                {
                    int idCompetition = (int)row.ItemArray[0];
                    string titleCompetition = (string)row.ItemArray[1];

                    competition.Items.Add(new KeyValuePair<int, string>(idCompetition, titleCompetition));
                }

                dataTable = database.returnDataTable($"select id, FullName from users where role_id = 3 and [competition] = {idChemp}");
                foreach (DataRow row in dataTable.Rows)
                {
                    int idCompetition = (int)row.ItemArray[0];
                    string titleCompetition = (string)row.ItemArray[1];

                    expert.Items.Add(new KeyValuePair<int, string>(idCompetition, titleCompetition));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"При выполнении запроса произошла ошибка {ex.Message}, обратитесь к специалисту");
            }

           
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
