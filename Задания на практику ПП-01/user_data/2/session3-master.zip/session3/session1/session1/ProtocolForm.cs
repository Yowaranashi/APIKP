﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace session1
{
    public partial class ProtocolForm : Form
    {
        int competitionId;
        int skillId;
        public ProtocolForm(int competitionId, int skillId)
        {
            this.competitionId = competitionId;
            this.skillId = skillId;
            InitializeComponent();
        }



        /// <summary>
        /// Вызов формы регистрации экспертов на площадке
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ShowRegistrationExpertForm_Click(object sender, EventArgs e)
        {
            Visible = false;
            var registrationExpert = new RegistrationExpert(competitionId, skillId);
            registrationExpert.ShowDialog();
            Visible = true;
        }


        /// <summary>
        /// Вызов формы ознакомления экспертов с техникой безопасности
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ShowTechnikalSecurityForm_Click(object sender, EventArgs e)
        {
            Visible = false;
            var technikalSecurityForm = new TechnikalSecurityForm(competitionId, skillId);
            technikalSecurityForm.ShowDialog();
            Visible = true;
        }

        /// <summary>
        /// Вызов формы внесения 30% процентов изменений в конкурсное задание
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ShowEditingForm_Click(object sender, EventArgs e)
        {
            Visible = false;
            var editingForm = new EditingForm(competitionId, skillId);
            editingForm.ShowDialog();
            Visible = true;
        }


        /// <summary>
        /// Вызов формы ознакомления с ведомостями оценки
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void showMarksForm_Click(object sender, EventArgs e)
        {
            Visible = false;
            var markForm = new MarksForm(competitionId, skillId);
            markForm.ShowDialog();
            Visible = true;
        }

        /// <summary>
        /// Вызов формы распределения судейских ролей
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ShowRoleForm_Click(object sender, EventArgs e)
        {
            Visible = false;
            var roleForm = new RoleForm(competitionId, skillId);
            roleForm.ShowDialog();
            Visible = true;
        }
    }
}
