﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SQLlib;
namespace session1
{
    public partial class ExpertForm : Form
    {
        SQL database = new SQL();
        int expertId;
        int competitionId;
        int skillId;
        /// <summary>
        /// Конструктор формы, инициализирующий окно экспера
        /// </summary>
        /// <param name="expertId">id эксперта</param>
        /// <param name="competitionId">id чемпионата</param>
        /// <param name="skillId">id компетенции</param>
        public ExpertForm(int expertId, int competitionId, int skillId)
        {
            this.expertId = expertId;
            this.competitionId = competitionId;
            this.skillId = skillId;
            InitializeComponent();
            showInformation(expertId, competitionId, skillId);
        }


        /// <summary>
        /// Вывод информации о эксперте, чемпионате и компетенции
        /// </summary>
        public void showInformation(int expertId, int competitionId, int skillId)
        {

           string fullName = database.ExecuteScalar<string>($"select FullName from users where id = {expertId}");
            int idCompetition = database.ExecuteScalar<int>($"select competition from users where id= {expertId}");
            string nameOfCompetition = database.ExecuteScalar<string>($"select title from competition where id = {competitionId}");
            int idSkill = database.ExecuteScalar<int>($"select skill from users where id= {expertId}");
            //DateTime cur = new DateTime(2023, 1, 1, 5,59,0);
            DateTime cur = DateTime.Now.AddHours(11).AddMinutes(1);
            var strartMorning = new TimeSpan(6, 0, 0);
            var endMorning = new TimeSpan(11, 0, 0);
            var strartDay = new TimeSpan(11, 1, 0);
            var endDay = new TimeSpan(17, 59, 0);
            var strartEvening = new TimeSpan(18, 0, 0);
            var endEvening = new TimeSpan(23, 0, 0);
            var strarNight = new TimeSpan(23, 1, 0);
            var endNight = new TimeSpan(5, 59, 0);
            var nullTime = new TimeSpan(24,0,0);
            string timeNow = "";
            if ((cur.Hour >= strartMorning.Hours && cur.Hour <= endMorning.Hours ))
            {
                if (cur.Hour == endMorning.Hours)
                {
                    if(cur.Minute > endMorning.Minutes){
                        timeNow = "";
                    }
                    else
                    {
                        timeNow = "Доброе утро ";
                    }
                   
                }
                else
                {
                    timeNow = "Доброе утро ";
                }
                
            }
            if ((cur.Hour >= strartDay.Hours && cur.Hour <= endDay.Hours))
            {
                if(cur.Hour == strartDay.Hours)
                {
                    if (cur.Minute < strartDay.Minutes)
                    {
                        timeNow = "";
                    }
                    else
                    {
                        timeNow = "Добрый день ";
                    }
                }
                else
                {
                    timeNow = "Добрый день ";
                }
            }
            if ((cur.Hour >= strartEvening.Hours && cur.Hour <= endEvening.Hours))
            {
                if (cur.Hour == endEvening.Hours)
                {
                    if (cur.Minute > endEvening.Minutes)
                    {
                        timeNow = "";
                    }
                    else
                    {
                        timeNow = "Добрый вечер ";
                    }
                }
                else
                {
                    timeNow = "Добрый вечер ";
                }
            }
           if((cur.Hour >= strarNight.Hours && cur.Hour <= nullTime.TotalHours) || (cur.Hour >= nullTime.Hours && cur.Hour <= endNight.Hours))
           {
                if (cur.Hour == strarNight.Hours)
                {
                    if (cur.Minute < strarNight.Minutes)
                    {
                        timeNow = "";
                    }
                    else
                    {
                        timeNow = "Доброй ночи ";
                    }
                }
                else
                {
                    timeNow = "Доброй ночи ";
                }
            }
            string nameOfSkill = database.ExecuteScalar<string>($"select title from skills where id = {skillId}");
            hello.Text = timeNow + fullName;
            competitionName.Text = nameOfCompetition;
            skillName.Text = nameOfSkill;

        }
        /// <summary>
        /// Метод закрытия формы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void close_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Метод для вывод информации о участниках
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void peopleList_Click(object sender, EventArgs e)
        {
            add.Visible = true;
            edit.Visible = true;
            save.Visible = true;
            del.Visible = true;
            saveList.Visible = true;
            var dataTable = database.returnDataTable($"select FullName, birthday from users where skill = {skillId} and competition = {competitionId} and role_id = 1");

            content.DataSource = dataTable;


            //content.RowCount = dataTable.Rows.Count;
          

            //var fullName = database.ExecuteScalar<string>($"select FullName from users where skill = {skillId} and competition = {competitionId} and role_id = 1");
            //var partFullName = fullName.Split(' ');
            //var birthday = database.ExecuteScalar<DateTime>($"select birthday from users where skill = {skillId} and competition = {competitionId} and role_id = 1");

        }


        /// <summary>
        /// Метод для вывода информации о экспертах
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void expertList_Click(object sender, EventArgs e)
        {
            add.Visible = true;
            edit.Visible = true;
            del.Visible = true;
            save.Visible = true;
            saveList.Visible = true;
            content.DataSource = null;
            var dataTable = database.returnDataTable($"select FullName, birthday from users where skill = {skillId} and competition = {competitionId} and role_id = 2");

            content.DataSource = dataTable;
        }


        /// <summary>
        /// Метод для вывода протоколов 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void protocol_Click(object sender, EventArgs e)
        {
            add.Visible = false;
            edit.Visible = false;
            save.Visible = false;
            del.Visible = false;
            saveList.Visible = false;
            content.DataSource = null;
            Visible = false;
            var protocolForm = new ProtocolForm(competitionId, skillId);
            protocolForm.ShowDialog();
            Visible = true;
        }
    }
}
