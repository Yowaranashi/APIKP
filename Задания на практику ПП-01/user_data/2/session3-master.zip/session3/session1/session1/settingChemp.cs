﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SQLlib;
namespace session1
{
    public partial class settingChemp : Form
    {
        int organizationId;
        int chempId;
        SQL database = new SQL();
        public settingChemp(int id, int chempId)
        {
            try
            {
                InitializeComponent();
                organizationId = id;
                this.chempId = chempId;
                string name = database.ExecuteScalar<string>($"select FullName from users where id = {organizationId}");
                hello.Text = name;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"При выполнении запроса произошла ошибка {ex.Message}, обратитесь к специалисту");
            }
           
            
        }

        private void close_Click(object sender, EventArgs e)
        {
            Close();
        }


        /// <summary>
        /// Получение списка участников
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void peopleList_Click(object sender, EventArgs e)
        {
            try
            {
                var dataTable = database.returnDataTable($"select id, FullName as ФИО , role_id as Роль from users where competition = {chempId} and role_id != 6");
                content.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"При выполнении запроса произошла ошибка {ex.Message}, обратитесь к специалисту");
            }
            
        }

        private void listExpert_Click(object sender, EventArgs e)
        {
            database.returnDataTable($"select * from users where role_id = 6 and competition = {chempId}");
        }
    }
}
