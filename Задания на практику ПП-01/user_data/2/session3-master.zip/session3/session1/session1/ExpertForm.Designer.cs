﻿namespace session1
{
    partial class ExpertForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.close = new System.Windows.Forms.Button();
            this.peopleList = new System.Windows.Forms.Button();
            this.expertList = new System.Windows.Forms.Button();
            this.protocol = new System.Windows.Forms.Button();
            this.content = new System.Windows.Forms.DataGridView();
            this.competitionName = new System.Windows.Forms.Label();
            this.skillName = new System.Windows.Forms.Label();
            this.hello = new System.Windows.Forms.Label();
            this.add = new System.Windows.Forms.Button();
            this.edit = new System.Windows.Forms.Button();
            this.del = new System.Windows.Forms.Button();
            this.saveList = new System.Windows.Forms.Button();
            this.save = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.content)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // close
            // 
            this.close.BackColor = System.Drawing.Color.Blue;
            this.close.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.close.ForeColor = System.Drawing.Color.White;
            this.close.Location = new System.Drawing.Point(12, 12);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(102, 47);
            this.close.TabIndex = 1;
            this.close.Text = "Выход";
            this.close.UseVisualStyleBackColor = false;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // peopleList
            // 
            this.peopleList.BackColor = System.Drawing.Color.Blue;
            this.peopleList.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.peopleList.ForeColor = System.Drawing.Color.White;
            this.peopleList.Location = new System.Drawing.Point(12, 154);
            this.peopleList.Name = "peopleList";
            this.peopleList.Size = new System.Drawing.Size(218, 46);
            this.peopleList.TabIndex = 3;
            this.peopleList.Text = "Списко участников";
            this.peopleList.UseVisualStyleBackColor = false;
            this.peopleList.Click += new System.EventHandler(this.peopleList_Click);
            // 
            // expertList
            // 
            this.expertList.BackColor = System.Drawing.Color.Blue;
            this.expertList.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.expertList.ForeColor = System.Drawing.Color.White;
            this.expertList.Location = new System.Drawing.Point(12, 221);
            this.expertList.Name = "expertList";
            this.expertList.Size = new System.Drawing.Size(218, 47);
            this.expertList.TabIndex = 4;
            this.expertList.Text = "Список экспертов";
            this.expertList.UseVisualStyleBackColor = false;
            this.expertList.Click += new System.EventHandler(this.expertList_Click);
            // 
            // protocol
            // 
            this.protocol.BackColor = System.Drawing.Color.Blue;
            this.protocol.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.protocol.ForeColor = System.Drawing.Color.White;
            this.protocol.Location = new System.Drawing.Point(12, 288);
            this.protocol.Name = "protocol";
            this.protocol.Size = new System.Drawing.Size(218, 47);
            this.protocol.TabIndex = 5;
            this.protocol.Text = "Протоколы";
            this.protocol.UseVisualStyleBackColor = false;
            this.protocol.Click += new System.EventHandler(this.protocol_Click);
            // 
            // content
            // 
            this.content.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.content.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.content.Location = new System.Drawing.Point(501, 154);
            this.content.Name = "content";
            this.content.Size = new System.Drawing.Size(512, 181);
            this.content.TabIndex = 6;
            // 
            // competitionName
            // 
            this.competitionName.AutoSize = true;
            this.competitionName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.competitionName.Location = new System.Drawing.Point(365, 24);
            this.competitionName.Name = "competitionName";
            this.competitionName.Size = new System.Drawing.Size(60, 24);
            this.competitionName.TabIndex = 7;
            this.competitionName.Text = "label1";
            // 
            // skillName
            // 
            this.skillName.AutoSize = true;
            this.skillName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.skillName.Location = new System.Drawing.Point(365, 63);
            this.skillName.Name = "skillName";
            this.skillName.Size = new System.Drawing.Size(60, 24);
            this.skillName.TabIndex = 8;
            this.skillName.Text = "label2";
            // 
            // hello
            // 
            this.hello.AutoSize = true;
            this.hello.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.hello.Location = new System.Drawing.Point(12, 97);
            this.hello.Name = "hello";
            this.hello.Size = new System.Drawing.Size(51, 24);
            this.hello.TabIndex = 9;
            this.hello.Text = "hello";
            // 
            // add
            // 
            this.add.BackColor = System.Drawing.Color.Blue;
            this.add.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.add.ForeColor = System.Drawing.Color.White;
            this.add.Location = new System.Drawing.Point(501, 362);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(147, 46);
            this.add.TabIndex = 11;
            this.add.Text = "Добавить";
            this.add.UseVisualStyleBackColor = false;
            this.add.Visible = false;
            // 
            // edit
            // 
            this.edit.BackColor = System.Drawing.Color.Blue;
            this.edit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.edit.ForeColor = System.Drawing.Color.White;
            this.edit.Location = new System.Drawing.Point(667, 362);
            this.edit.Name = "edit";
            this.edit.Size = new System.Drawing.Size(152, 46);
            this.edit.TabIndex = 12;
            this.edit.Text = "Изменить";
            this.edit.UseVisualStyleBackColor = false;
            this.edit.Visible = false;
            // 
            // del
            // 
            this.del.BackColor = System.Drawing.Color.Red;
            this.del.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.del.ForeColor = System.Drawing.Color.White;
            this.del.Location = new System.Drawing.Point(861, 362);
            this.del.Name = "del";
            this.del.Size = new System.Drawing.Size(152, 46);
            this.del.TabIndex = 13;
            this.del.Text = "Удалить";
            this.del.UseVisualStyleBackColor = false;
            this.del.Visible = false;
            // 
            // saveList
            // 
            this.saveList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.saveList.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.saveList.ForeColor = System.Drawing.Color.White;
            this.saveList.Location = new System.Drawing.Point(784, 43);
            this.saveList.Name = "saveList";
            this.saveList.Size = new System.Drawing.Size(214, 63);
            this.saveList.TabIndex = 14;
            this.saveList.Text = "Зафиксировать список";
            this.saveList.UseVisualStyleBackColor = false;
            this.saveList.Visible = false;
            // 
            // save
            // 
            this.save.BackColor = System.Drawing.Color.Blue;
            this.save.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.save.ForeColor = System.Drawing.Color.White;
            this.save.Location = new System.Drawing.Point(667, 444);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(152, 46);
            this.save.TabIndex = 15;
            this.save.Text = "Сохранить";
            this.save.UseVisualStyleBackColor = false;
            this.save.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::session1.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(1048, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(226, 117);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // ExpertForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1308, 513);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.save);
            this.Controls.Add(this.saveList);
            this.Controls.Add(this.del);
            this.Controls.Add(this.edit);
            this.Controls.Add(this.add);
            this.Controls.Add(this.hello);
            this.Controls.Add(this.skillName);
            this.Controls.Add(this.competitionName);
            this.Controls.Add(this.content);
            this.Controls.Add(this.protocol);
            this.Controls.Add(this.expertList);
            this.Controls.Add(this.peopleList);
            this.Controls.Add(this.close);
            this.Name = "ExpertForm";
            this.Text = "ExpertForm";
            ((System.ComponentModel.ISupportInitialize)(this.content)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button close;
        private System.Windows.Forms.Button peopleList;
        private System.Windows.Forms.Button expertList;
        private System.Windows.Forms.Button protocol;
        private System.Windows.Forms.DataGridView content;
        private System.Windows.Forms.Label competitionName;
        private System.Windows.Forms.Label skillName;
        private System.Windows.Forms.Label hello;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Button edit;
        private System.Windows.Forms.Button del;
        private System.Windows.Forms.Button saveList;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}