﻿namespace session1
{
    partial class ProtocolForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dayCminus2 = new System.Windows.Forms.Button();
            this.dayCminus1 = new System.Windows.Forms.Button();
            this.dayC1 = new System.Windows.Forms.Button();
            this.dayC2 = new System.Windows.Forms.Button();
            this.dayCplus1 = new System.Windows.Forms.Button();
            this.ShowRegistrationExpertForm = new System.Windows.Forms.Button();
            this.ShowTechnikalSecurityForm = new System.Windows.Forms.Button();
            this.ShowEditingForm = new System.Windows.Forms.Button();
            this.showMarksForm = new System.Windows.Forms.Button();
            this.ShowRoleForm = new System.Windows.Forms.Button();
            this.report = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dayCminus2
            // 
            this.dayCminus2.BackColor = System.Drawing.Color.Blue;
            this.dayCminus2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dayCminus2.ForeColor = System.Drawing.Color.White;
            this.dayCminus2.Location = new System.Drawing.Point(12, 51);
            this.dayCminus2.Name = "dayCminus2";
            this.dayCminus2.Size = new System.Drawing.Size(212, 58);
            this.dayCminus2.TabIndex = 2;
            this.dayCminus2.Text = "День С-2";
            this.dayCminus2.UseVisualStyleBackColor = false;
            // 
            // dayCminus1
            // 
            this.dayCminus1.BackColor = System.Drawing.Color.Blue;
            this.dayCminus1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dayCminus1.ForeColor = System.Drawing.Color.White;
            this.dayCminus1.Location = new System.Drawing.Point(12, 125);
            this.dayCminus1.Name = "dayCminus1";
            this.dayCminus1.Size = new System.Drawing.Size(212, 58);
            this.dayCminus1.TabIndex = 3;
            this.dayCminus1.Text = "День С-1";
            this.dayCminus1.UseVisualStyleBackColor = false;
            // 
            // dayC1
            // 
            this.dayC1.BackColor = System.Drawing.Color.Blue;
            this.dayC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dayC1.ForeColor = System.Drawing.Color.White;
            this.dayC1.Location = new System.Drawing.Point(12, 206);
            this.dayC1.Name = "dayC1";
            this.dayC1.Size = new System.Drawing.Size(212, 64);
            this.dayC1.TabIndex = 4;
            this.dayC1.Text = "День С1";
            this.dayC1.UseVisualStyleBackColor = false;
            // 
            // dayC2
            // 
            this.dayC2.BackColor = System.Drawing.Color.Blue;
            this.dayC2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dayC2.ForeColor = System.Drawing.Color.White;
            this.dayC2.Location = new System.Drawing.Point(12, 276);
            this.dayC2.Name = "dayC2";
            this.dayC2.Size = new System.Drawing.Size(212, 67);
            this.dayC2.TabIndex = 5;
            this.dayC2.Text = "День С2";
            this.dayC2.UseVisualStyleBackColor = false;
            // 
            // dayCplus1
            // 
            this.dayCplus1.BackColor = System.Drawing.Color.Blue;
            this.dayCplus1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dayCplus1.ForeColor = System.Drawing.Color.White;
            this.dayCplus1.Location = new System.Drawing.Point(12, 362);
            this.dayCplus1.Name = "dayCplus1";
            this.dayCplus1.Size = new System.Drawing.Size(212, 61);
            this.dayCplus1.TabIndex = 6;
            this.dayCplus1.Text = "День С+1";
            this.dayCplus1.UseVisualStyleBackColor = false;
            // 
            // ShowRegistrationExpertForm
            // 
            this.ShowRegistrationExpertForm.BackColor = System.Drawing.Color.Blue;
            this.ShowRegistrationExpertForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ShowRegistrationExpertForm.ForeColor = System.Drawing.Color.White;
            this.ShowRegistrationExpertForm.Location = new System.Drawing.Point(314, 51);
            this.ShowRegistrationExpertForm.Name = "ShowRegistrationExpertForm";
            this.ShowRegistrationExpertForm.Size = new System.Drawing.Size(456, 58);
            this.ShowRegistrationExpertForm.TabIndex = 7;
            this.ShowRegistrationExpertForm.Text = "Регистрация экспертов на площадке (0/15)";
            this.ShowRegistrationExpertForm.UseVisualStyleBackColor = false;
            this.ShowRegistrationExpertForm.Click += new System.EventHandler(this.ShowRegistrationExpertForm_Click);
            // 
            // ShowTechnikalSecurityForm
            // 
            this.ShowTechnikalSecurityForm.BackColor = System.Drawing.Color.Blue;
            this.ShowTechnikalSecurityForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ShowTechnikalSecurityForm.ForeColor = System.Drawing.Color.White;
            this.ShowTechnikalSecurityForm.Location = new System.Drawing.Point(314, 125);
            this.ShowTechnikalSecurityForm.Name = "ShowTechnikalSecurityForm";
            this.ShowTechnikalSecurityForm.Size = new System.Drawing.Size(456, 58);
            this.ShowTechnikalSecurityForm.TabIndex = 8;
            this.ShowTechnikalSecurityForm.Text = "Ознакомление экспертов с техникой безопасности (0/15)";
            this.ShowTechnikalSecurityForm.UseVisualStyleBackColor = false;
            this.ShowTechnikalSecurityForm.Click += new System.EventHandler(this.ShowTechnikalSecurityForm_Click);
            // 
            // ShowEditingForm
            // 
            this.ShowEditingForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.ShowEditingForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ShowEditingForm.ForeColor = System.Drawing.Color.White;
            this.ShowEditingForm.Location = new System.Drawing.Point(314, 206);
            this.ShowEditingForm.Name = "ShowEditingForm";
            this.ShowEditingForm.Size = new System.Drawing.Size(456, 64);
            this.ShowEditingForm.TabIndex = 9;
            this.ShowEditingForm.Text = "Внесение 30% изменений в задание (15/15)";
            this.ShowEditingForm.UseVisualStyleBackColor = false;
            this.ShowEditingForm.Click += new System.EventHandler(this.ShowEditingForm_Click);
            // 
            // showMarksForm
            // 
            this.showMarksForm.BackColor = System.Drawing.Color.Blue;
            this.showMarksForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.showMarksForm.ForeColor = System.Drawing.Color.White;
            this.showMarksForm.Location = new System.Drawing.Point(314, 276);
            this.showMarksForm.Name = "showMarksForm";
            this.showMarksForm.Size = new System.Drawing.Size(456, 67);
            this.showMarksForm.TabIndex = 10;
            this.showMarksForm.Text = "Ознакомление с ведомостями оценки (10/15)";
            this.showMarksForm.UseVisualStyleBackColor = false;
            this.showMarksForm.Click += new System.EventHandler(this.showMarksForm_Click);
            // 
            // ShowRoleForm
            // 
            this.ShowRoleForm.BackColor = System.Drawing.Color.Blue;
            this.ShowRoleForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ShowRoleForm.ForeColor = System.Drawing.Color.White;
            this.ShowRoleForm.Location = new System.Drawing.Point(314, 362);
            this.ShowRoleForm.Name = "ShowRoleForm";
            this.ShowRoleForm.Size = new System.Drawing.Size(456, 61);
            this.ShowRoleForm.TabIndex = 11;
            this.ShowRoleForm.Text = "Распределение судейских ролей (0/15)";
            this.ShowRoleForm.UseVisualStyleBackColor = false;
            this.ShowRoleForm.Click += new System.EventHandler(this.ShowRoleForm_Click);
            // 
            // report
            // 
            this.report.BackColor = System.Drawing.Color.Blue;
            this.report.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.report.ForeColor = System.Drawing.Color.White;
            this.report.Location = new System.Drawing.Point(220, 490);
            this.report.Name = "report";
            this.report.Size = new System.Drawing.Size(237, 61);
            this.report.TabIndex = 12;
            this.report.Text = "Отчет о подписании";
            this.report.UseVisualStyleBackColor = false;
            // 
            // ProtocolForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(904, 563);
            this.Controls.Add(this.report);
            this.Controls.Add(this.ShowRoleForm);
            this.Controls.Add(this.showMarksForm);
            this.Controls.Add(this.ShowEditingForm);
            this.Controls.Add(this.ShowTechnikalSecurityForm);
            this.Controls.Add(this.ShowRegistrationExpertForm);
            this.Controls.Add(this.dayCplus1);
            this.Controls.Add(this.dayC2);
            this.Controls.Add(this.dayC1);
            this.Controls.Add(this.dayCminus1);
            this.Controls.Add(this.dayCminus2);
            this.Name = "ProtocolForm";
            this.Text = "ProtocolForm";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button dayCminus2;
        private System.Windows.Forms.Button dayCminus1;
        private System.Windows.Forms.Button dayC1;
        private System.Windows.Forms.Button dayC2;
        private System.Windows.Forms.Button dayCplus1;
        private System.Windows.Forms.Button ShowRegistrationExpertForm;
        private System.Windows.Forms.Button ShowTechnikalSecurityForm;
        private System.Windows.Forms.Button ShowEditingForm;
        private System.Windows.Forms.Button showMarksForm;
        private System.Windows.Forms.Button ShowRoleForm;
        private System.Windows.Forms.Button report;
    }
}