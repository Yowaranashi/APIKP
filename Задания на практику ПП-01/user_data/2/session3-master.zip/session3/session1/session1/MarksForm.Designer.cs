﻿namespace session1
{
    partial class MarksForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.content = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.chooseDay = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.timeCIS = new System.Windows.Forms.Button();
            this.electronicCheck = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.content)).BeginInit();
            this.SuspendLayout();
            // 
            // content
            // 
            this.content.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.content.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.content.Location = new System.Drawing.Point(147, 79);
            this.content.Name = "content";
            this.content.Size = new System.Drawing.Size(512, 167);
            this.content.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(199, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(374, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Протокол ознакомления с ведомостями оценки";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(185, 296);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Дата протокола";
            // 
            // chooseDay
            // 
            this.chooseDay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chooseDay.FormattingEnabled = true;
            this.chooseDay.Items.AddRange(new object[] {
            "C-2",
            "C-1",
            "C1",
            "C2",
            "C+1"});
            this.chooseDay.Location = new System.Drawing.Point(349, 295);
            this.chooseDay.Name = "chooseDay";
            this.chooseDay.Size = new System.Drawing.Size(121, 28);
            this.chooseDay.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(185, 342);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(149, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Временной штамп";
            // 
            // timeCIS
            // 
            this.timeCIS.BackColor = System.Drawing.Color.Blue;
            this.timeCIS.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.timeCIS.ForeColor = System.Drawing.Color.White;
            this.timeCIS.Location = new System.Drawing.Point(349, 333);
            this.timeCIS.Name = "timeCIS";
            this.timeCIS.Size = new System.Drawing.Size(288, 35);
            this.timeCIS.TabIndex = 5;
            this.timeCIS.Text = "Временной штамп из CIS";
            this.timeCIS.UseVisualStyleBackColor = false;
            // 
            // electronicCheck
            // 
            this.electronicCheck.BackColor = System.Drawing.Color.Blue;
            this.electronicCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.electronicCheck.ForeColor = System.Drawing.Color.White;
            this.electronicCheck.Location = new System.Drawing.Point(252, 398);
            this.electronicCheck.Name = "electronicCheck";
            this.electronicCheck.Size = new System.Drawing.Size(321, 80);
            this.electronicCheck.TabIndex = 6;
            this.electronicCheck.Text = "Использовать электронное подписание";
            this.electronicCheck.UseVisualStyleBackColor = false;
            this.electronicCheck.Click += new System.EventHandler(this.electronicCheck_Click);
            // 
            // MarksForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(843, 504);
            this.Controls.Add(this.electronicCheck);
            this.Controls.Add(this.timeCIS);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.chooseDay);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.content);
            this.Name = "MarksForm";
            this.Text = "MarksForm";
            ((System.ComponentModel.ISupportInitialize)(this.content)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView content;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox chooseDay;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button timeCIS;
        private System.Windows.Forms.Button electronicCheck;
    }
}