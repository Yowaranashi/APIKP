﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SQLlib;
using System.Data.SqlClient;
using System.Data;
namespace session1
{
    public partial class autoresation : Form
    {
        public autoresation()
        {
            InitializeComponent();
        }

        static string connectionString = @"Data Source=WM-SQL-SERVER\SQLEXPRESS01;Initial Catalog=db_bsn_user2;User ID=bsn_user2;Password=wlu6rh";


        SQL database = new SQL();
        /// <summary>
        /// Событие для входа в систему
        /// </summary>
        /// <param name="sender">Отправитель</param>
        /// <param name="e">Аргумент события</param>
        private void login_Click(object sender, EventArgs e)
        {

            try
            {
                string PIN = loginText.Text;
                string pass = password.Text;
                int id = database.ExecuteScalar<int>($"select id from users where PIN = '{PIN}' and password = '{pass}'");

                if (id > 0)
                {
                    int roleId = database.ExecuteScalar<int>($"select role_id from users where id = {id}");
                    if (roleId == 6)
                    {
                        Visible = false;
                        var orgForm = new organizatorForm(id);
                        orgForm.ShowDialog();
                        Visible = true;
                    }
                    else if (roleId == 2)
                    {
                        int competitionId = database.ExecuteScalar<int>($"select [competition] from users where id = {id}");
                        int skillId = database.ExecuteScalar<int>($"select skill from users where id = {id}");
                        Visible = false;
                        var expertForm = new ExpertForm(id, competitionId, skillId);
                        expertForm.ShowDialog();
                        Visible = true;
                    }
                }
                else
                {
                    throw new Exception("Ошибка подключения");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("При авторизации произошла проблема, пожалуйста обратитесь к специалисту");
            }
            

        }


        /// <summary>
        /// Метод для сохранения пароля
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveMe_CheckedChanged(object sender, EventArgs e)
        {
            
        }
    }
}
