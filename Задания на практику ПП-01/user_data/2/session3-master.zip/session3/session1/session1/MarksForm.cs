﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SQLlib;
namespace session1
{
    public partial class MarksForm : Form
    {
        SQL database = new SQL();
        int competitionId;
        int skillId;
        public MarksForm(int competitionId, int skillId)
        {
            this.competitionId = competitionId;
            this.skillId = skillId;
            InitializeComponent();
            loadExpert();
        }

        /// <summary>
        /// Метод закгрузки экспертов
        /// </summary>
        private void loadExpert()
        {
            content.DataSource = database.returnDataTable($"select FullName as ФИО ,birthday as [Дата рождения] from users where competition = {competitionId} and skill = {skillId} and role_id = 2");
        }

        /// <summary>
        /// Метод подписания протокола
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void electronicCheck_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Протокол подписан");
        }
    }
}
