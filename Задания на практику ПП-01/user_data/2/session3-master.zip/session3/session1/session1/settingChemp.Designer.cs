﻿namespace session1
{
    partial class settingChemp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.close = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.hello = new System.Windows.Forms.Label();
            this.peopleList = new System.Windows.Forms.Button();
            this.settingChempionat = new System.Windows.Forms.Button();
            this.listExpert = new System.Windows.Forms.Button();
            this.report = new System.Windows.Forms.Button();
            this.content = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.content)).BeginInit();
            this.SuspendLayout();
            // 
            // close
            // 
            this.close.BackColor = System.Drawing.Color.Blue;
            this.close.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.close.ForeColor = System.Drawing.Color.White;
            this.close.Location = new System.Drawing.Point(12, 12);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(102, 47);
            this.close.TabIndex = 1;
            this.close.Text = "Выход";
            this.close.UseVisualStyleBackColor = false;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::session1.Properties.Resources.wsrlogo_01;
            this.pictureBox1.Location = new System.Drawing.Point(545, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(225, 86);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(12, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(216, 24);
            this.label2.TabIndex = 14;
            this.label2.Text = "Техническая дирекция";
            // 
            // hello
            // 
            this.hello.AutoSize = true;
            this.hello.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.hello.Location = new System.Drawing.Point(12, 111);
            this.hello.Name = "hello";
            this.hello.Size = new System.Drawing.Size(0, 24);
            this.hello.TabIndex = 15;
            // 
            // peopleList
            // 
            this.peopleList.BackColor = System.Drawing.Color.Blue;
            this.peopleList.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.peopleList.ForeColor = System.Drawing.Color.White;
            this.peopleList.Location = new System.Drawing.Point(16, 154);
            this.peopleList.Name = "peopleList";
            this.peopleList.Size = new System.Drawing.Size(222, 67);
            this.peopleList.TabIndex = 16;
            this.peopleList.Text = "Список участников";
            this.peopleList.UseVisualStyleBackColor = false;
            this.peopleList.Click += new System.EventHandler(this.peopleList_Click);
            // 
            // settingChempionat
            // 
            this.settingChempionat.BackColor = System.Drawing.Color.Blue;
            this.settingChempionat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.settingChempionat.ForeColor = System.Drawing.Color.White;
            this.settingChempionat.Location = new System.Drawing.Point(16, 227);
            this.settingChempionat.Name = "settingChempionat";
            this.settingChempionat.Size = new System.Drawing.Size(222, 67);
            this.settingChempionat.TabIndex = 17;
            this.settingChempionat.Text = "Настройка чемпионата";
            this.settingChempionat.UseVisualStyleBackColor = false;
            // 
            // listExpert
            // 
            this.listExpert.BackColor = System.Drawing.Color.Blue;
            this.listExpert.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.listExpert.ForeColor = System.Drawing.Color.White;
            this.listExpert.Location = new System.Drawing.Point(16, 300);
            this.listExpert.Name = "listExpert";
            this.listExpert.Size = new System.Drawing.Size(222, 62);
            this.listExpert.TabIndex = 18;
            this.listExpert.Text = "Список главных экспертов";
            this.listExpert.UseVisualStyleBackColor = false;
            this.listExpert.Click += new System.EventHandler(this.listExpert_Click);
            // 
            // report
            // 
            this.report.BackColor = System.Drawing.Color.Blue;
            this.report.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.report.ForeColor = System.Drawing.Color.White;
            this.report.Location = new System.Drawing.Point(16, 368);
            this.report.Name = "report";
            this.report.Size = new System.Drawing.Size(222, 65);
            this.report.TabIndex = 19;
            this.report.Text = "Отчет по сданным протоколам";
            this.report.UseVisualStyleBackColor = false;
            // 
            // content
            // 
            this.content.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.content.Location = new System.Drawing.Point(277, 154);
            this.content.Name = "content";
            this.content.Size = new System.Drawing.Size(493, 279);
            this.content.TabIndex = 20;
            // 
            // settingChemp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.content);
            this.Controls.Add(this.report);
            this.Controls.Add(this.listExpert);
            this.Controls.Add(this.settingChempionat);
            this.Controls.Add(this.peopleList);
            this.Controls.Add(this.hello);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.close);
            this.Name = "settingChemp";
            this.Text = "settingChemp";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.content)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button close;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label hello;
        private System.Windows.Forms.Button peopleList;
        private System.Windows.Forms.Button settingChempionat;
        private System.Windows.Forms.Button listExpert;
        private System.Windows.Forms.Button report;
        private System.Windows.Forms.DataGridView content;
    }
}