﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SQLlib
{
    /// <summary>
    /// Класс для работы с БД
    /// </summary>
    public class SQL
    {
        static string connectionString =  @"Data Source=WM-SQL-SERVER\SQLEXPRESS01;Initial Catalog=db_bsn_user2;User ID=bsn_user2;Password=wlu6rh";


        /// <summary>
        /// Метод для выполнения SQL запроса и получения данных в формате DataTable
        /// </summary>
        /// <param name="query">SQL запрос</param>
        /// <returns> Данные в формате DataTable</returns>
        static public DataTable returnDataTable(string query)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            connection.Open();
                            var dataTable = new DataTable();
                            adapter.Fill(dataTable);
                            return dataTable;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"При выполнении запроса произошла ошибка {ex.Message}, пожалуйста, обратитесь к специалисту");
            }
        }


        /// <summary>
        /// Метод для выполнения запроса и получения данных в формате dataReader
        /// </summary>
        /// <param name="query">SQL запрос</param>
        /// <returns>Данные в формате DataReader</returns>
        static public SqlDataReader returnDataReader(string query)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        return command.ExecuteReader();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"При выполнении запроса произошла ошибка {ex.Message}, пожалуйста, обратитесь к специалисту");
            }
        }

        /// <summary>
        /// Метод для выполнения INSERT, UPDATE, DELETE запросов
        /// </summary>
        /// <param name="query">SQL запрос </param>
        static public void executeNonQuery(string query)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"При выполнении запроса произошла ошибка {ex.Message}, пожалуйста, обратитесь к специалисту");
            }
        }
    }
}
