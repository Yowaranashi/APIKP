﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SQLlib;
using System.Data.SqlClient;
using System.Data;
namespace session1
{
    public partial class autoresation : Form
    {
        public autoresation()
        {
            InitializeComponent();
        }

        static string connectionString = @"Data Source=WM-SQL-SERVER\SQLEXPRESS01;Initial Catalog=db_bsn_user2;User ID=bsn_user2;Password=wlu6rh";



        /// <summary>
        /// Событие для входа в систему
        /// </summary>
        /// <param name="sender">Отправитель</param>
        /// <param name="e">Аргумент события</param>
        private void login_Click(object sender, EventArgs e)
        {



            var PIN = loginText.Text;
            var passwordString = password.Text;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand($"select * from [users] where PIN = '{PIN}' and password = '{passwordString}'", connection))
                {
                    connection.Open();
                    var reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {

                        var role = reader.GetValue(7);

                        if (role == "Организатор")
                        {
                            Visible = false;
                            var techForm = new organizatorForm();
                            techForm.Show();
                            Visible = true;
                        }

                    }
                    else
                    {
                        throw new Exception("Введены некоректные данные");
                    }
                }
            }

            //try
            //{

            //    SqlConnection connection = new SqlConnection(connectionString);
            //    connection.Open();
            //    var PIN = int.Parse(loginText.Text);
            //    var passwordString = password.Text;

            //    var reader = SQL.returnDataReader($"select * from [users] where PIN = {PIN} and password = '{passwordString}'");


            //    if (true)
            //    {

            //        var role = reader.GetValue(7);

            //        if (role == "Организатор")
            //        {
            //            Visible = false;
            //            var techForm = new organizatorForm();
            //            techForm.Show();
            //            Visible = true;
            //        }

            //    }
            //    else
            //    {
            //        throw new Exception("Введены некоректные данные");
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show($"При входе возникла ошибка {ex.Message}");
            //}

        }


        /// <summary>
        /// Метод для сохранения пароля
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveMe_CheckedChanged(object sender, EventArgs e)
        {
            
        }
    }
}
