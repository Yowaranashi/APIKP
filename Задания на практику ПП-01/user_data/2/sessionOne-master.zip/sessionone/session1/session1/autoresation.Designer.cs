﻿namespace session1
{
    partial class autoresation
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.autoresation_label = new System.Windows.Forms.Label();
            this.loginText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.TextBox();
            this.saveMe = new System.Windows.Forms.CheckBox();
            this.login = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // autoresation_label
            // 
            this.autoresation_label.AutoSize = true;
            this.autoresation_label.Font = new System.Drawing.Font("Agency FB", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.autoresation_label.Location = new System.Drawing.Point(208, 100);
            this.autoresation_label.Name = "autoresation_label";
            this.autoresation_label.Size = new System.Drawing.Size(152, 25);
            this.autoresation_label.TabIndex = 0;
            this.autoresation_label.Text = "Авторизация";
            // 
            // loginText
            // 
            this.loginText.Location = new System.Drawing.Point(212, 149);
            this.loginText.Name = "loginText";
            this.loginText.Size = new System.Drawing.Size(223, 20);
            this.loginText.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(118, 145);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "Логин";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(118, 188);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 24);
            this.label2.TabIndex = 4;
            this.label2.Text = "Пароль";
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(212, 192);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(223, 20);
            this.password.TabIndex = 3;
            // 
            // saveMe
            // 
            this.saveMe.AutoSize = true;
            this.saveMe.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.saveMe.Location = new System.Drawing.Point(212, 242);
            this.saveMe.Name = "saveMe";
            this.saveMe.Size = new System.Drawing.Size(180, 28);
            this.saveMe.TabIndex = 6;
            this.saveMe.Text = "Запомнить меня";
            this.saveMe.UseVisualStyleBackColor = true;
            this.saveMe.CheckedChanged += new System.EventHandler(this.saveMe_CheckedChanged);
            // 
            // login
            // 
            this.login.BackColor = System.Drawing.Color.Blue;
            this.login.ForeColor = System.Drawing.Color.White;
            this.login.Location = new System.Drawing.Point(239, 291);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(136, 45);
            this.login.TabIndex = 7;
            this.login.Text = "Логин";
            this.login.UseVisualStyleBackColor = false;
            this.login.Click += new System.EventHandler(this.login_Click);
            // 
            // autoresation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.login);
            this.Controls.Add(this.saveMe);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.password);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.loginText);
            this.Controls.Add(this.autoresation_label);
            this.Name = "autoresation";
            this.Text = "autoresation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label autoresation_label;
        private System.Windows.Forms.TextBox loginText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.CheckBox saveMe;
        private System.Windows.Forms.Button login;
    }
}

