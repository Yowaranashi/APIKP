﻿namespace session1
{
    partial class organizatorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.close = new System.Windows.Forms.Button();
            this.logo = new System.Windows.Forms.PictureBox();
            this.chempionat = new System.Windows.Forms.Button();
            this.settingChemp = new System.Windows.Forms.Button();
            this.expertControl = new System.Windows.Forms.Button();
            this.protocol = new System.Windows.Forms.Button();
            this.content = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.content)).BeginInit();
            this.SuspendLayout();
            // 
            // close
            // 
            this.close.BackColor = System.Drawing.Color.Blue;
            this.close.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.close.ForeColor = System.Drawing.Color.White;
            this.close.Location = new System.Drawing.Point(12, 21);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(102, 47);
            this.close.TabIndex = 0;
            this.close.Text = "Выход";
            this.close.UseVisualStyleBackColor = false;
            // 
            // logo
            // 
            this.logo.BackgroundImage = global::session1.Properties.Resources.wsrlogo_01;
            this.logo.Location = new System.Drawing.Point(569, 12);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(168, 74);
            this.logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logo.TabIndex = 1;
            this.logo.TabStop = false;
            // 
            // chempionat
            // 
            this.chempionat.BackColor = System.Drawing.Color.Blue;
            this.chempionat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chempionat.ForeColor = System.Drawing.Color.White;
            this.chempionat.Location = new System.Drawing.Point(12, 119);
            this.chempionat.Name = "chempionat";
            this.chempionat.Size = new System.Drawing.Size(143, 62);
            this.chempionat.TabIndex = 2;
            this.chempionat.Text = "Чемпионат";
            this.chempionat.UseVisualStyleBackColor = false;
            // 
            // settingChemp
            // 
            this.settingChemp.BackColor = System.Drawing.Color.Blue;
            this.settingChemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.settingChemp.ForeColor = System.Drawing.Color.White;
            this.settingChemp.Location = new System.Drawing.Point(12, 187);
            this.settingChemp.Name = "settingChemp";
            this.settingChemp.Size = new System.Drawing.Size(143, 67);
            this.settingChemp.TabIndex = 3;
            this.settingChemp.Text = "Настройки чемпионата";
            this.settingChemp.UseVisualStyleBackColor = false;
            // 
            // expertControl
            // 
            this.expertControl.BackColor = System.Drawing.Color.Blue;
            this.expertControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.expertControl.ForeColor = System.Drawing.Color.White;
            this.expertControl.Location = new System.Drawing.Point(12, 260);
            this.expertControl.Name = "expertControl";
            this.expertControl.Size = new System.Drawing.Size(143, 67);
            this.expertControl.TabIndex = 4;
            this.expertControl.Text = "Управление экспертами";
            this.expertControl.UseVisualStyleBackColor = false;
            // 
            // protocol
            // 
            this.protocol.BackColor = System.Drawing.Color.Blue;
            this.protocol.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.protocol.ForeColor = System.Drawing.Color.White;
            this.protocol.Location = new System.Drawing.Point(12, 333);
            this.protocol.Name = "protocol";
            this.protocol.Size = new System.Drawing.Size(143, 47);
            this.protocol.TabIndex = 5;
            this.protocol.Text = "Протоколы";
            this.protocol.UseVisualStyleBackColor = false;
            // 
            // content
            // 
            this.content.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.content.Location = new System.Drawing.Point(175, 119);
            this.content.Name = "content";
            this.content.Size = new System.Drawing.Size(575, 261);
            this.content.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(170, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(294, 25);
            this.label1.TabIndex = 7;
            this.label1.Text = "ТЕХНИЧЕСКАЯ ДИРЕКЦИЯ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(175, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Добрый день, фио организаора";
            // 
            // organizatorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.content);
            this.Controls.Add(this.protocol);
            this.Controls.Add(this.expertControl);
            this.Controls.Add(this.settingChemp);
            this.Controls.Add(this.chempionat);
            this.Controls.Add(this.logo);
            this.Controls.Add(this.close);
            this.Name = "organizatorForm";
            this.Text = "technicalDirectionForm";
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.content)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button close;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.Button chempionat;
        private System.Windows.Forms.Button settingChemp;
        private System.Windows.Forms.Button expertControl;
        private System.Windows.Forms.Button protocol;
        private System.Windows.Forms.DataGridView content;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}