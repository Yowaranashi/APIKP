﻿namespace session1
{
    partial class organizatorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.close = new System.Windows.Forms.Button();
            this.chempionat = new System.Windows.Forms.Button();
            this.settingChemp = new System.Windows.Forms.Button();
            this.expertControl = new System.Windows.Forms.Button();
            this.protocol = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.selectChemp = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.start = new System.Windows.Forms.DateTimePicker();
            this.end = new System.Windows.Forms.DateTimePicker();
            this.logo = new System.Windows.Forms.PictureBox();
            this.name = new System.Windows.Forms.TextBox();
            this.competition = new System.Windows.Forms.ComboBox();
            this.expert = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.add = new System.Windows.Forms.Button();
            this.edit = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            this.SuspendLayout();
            // 
            // close
            // 
            this.close.BackColor = System.Drawing.Color.Blue;
            this.close.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.close.ForeColor = System.Drawing.Color.White;
            this.close.Location = new System.Drawing.Point(12, 21);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(102, 47);
            this.close.TabIndex = 0;
            this.close.Text = "Выход";
            this.close.UseVisualStyleBackColor = false;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // chempionat
            // 
            this.chempionat.BackColor = System.Drawing.Color.Blue;
            this.chempionat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chempionat.ForeColor = System.Drawing.Color.White;
            this.chempionat.Location = new System.Drawing.Point(12, 154);
            this.chempionat.Name = "chempionat";
            this.chempionat.Size = new System.Drawing.Size(143, 62);
            this.chempionat.TabIndex = 2;
            this.chempionat.Text = "Чемпионат";
            this.chempionat.UseVisualStyleBackColor = false;
            this.chempionat.Click += new System.EventHandler(this.chempionat_Click);
            // 
            // settingChemp
            // 
            this.settingChemp.BackColor = System.Drawing.Color.Blue;
            this.settingChemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.settingChemp.ForeColor = System.Drawing.Color.White;
            this.settingChemp.Location = new System.Drawing.Point(12, 222);
            this.settingChemp.Name = "settingChemp";
            this.settingChemp.Size = new System.Drawing.Size(143, 67);
            this.settingChemp.TabIndex = 3;
            this.settingChemp.Text = "Настройки чемпионата";
            this.settingChemp.UseVisualStyleBackColor = false;
            this.settingChemp.Click += new System.EventHandler(this.settingChemp_Click);
            // 
            // expertControl
            // 
            this.expertControl.BackColor = System.Drawing.Color.Blue;
            this.expertControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.expertControl.ForeColor = System.Drawing.Color.White;
            this.expertControl.Location = new System.Drawing.Point(12, 295);
            this.expertControl.Name = "expertControl";
            this.expertControl.Size = new System.Drawing.Size(143, 67);
            this.expertControl.TabIndex = 4;
            this.expertControl.Text = "Управление экспертами";
            this.expertControl.UseVisualStyleBackColor = false;
            // 
            // protocol
            // 
            this.protocol.BackColor = System.Drawing.Color.Blue;
            this.protocol.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.protocol.ForeColor = System.Drawing.Color.White;
            this.protocol.Location = new System.Drawing.Point(12, 368);
            this.protocol.Name = "protocol";
            this.protocol.Size = new System.Drawing.Size(143, 47);
            this.protocol.TabIndex = 5;
            this.protocol.Text = "Протоколы";
            this.protocol.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(170, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(294, 25);
            this.label1.TabIndex = 7;
            this.label1.Text = "ТЕХНИЧЕСКАЯ ДИРЕКЦИЯ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(175, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Добрый день, фио организаора";
            // 
            // selectChemp
            // 
            this.selectChemp.FormattingEnabled = true;
            this.selectChemp.Location = new System.Drawing.Point(12, 94);
            this.selectChemp.Name = "selectChemp";
            this.selectChemp.Size = new System.Drawing.Size(143, 21);
            this.selectChemp.TabIndex = 9;
            this.selectChemp.SelectedIndexChanged += new System.EventHandler(this.selectChemp_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(209, 214);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Даты чемпионата";
            // 
            // start
            // 
            this.start.Location = new System.Drawing.Point(313, 214);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(141, 20);
            this.start.TabIndex = 13;
            // 
            // end
            // 
            this.end.Location = new System.Drawing.Point(472, 214);
            this.end.Name = "end";
            this.end.Size = new System.Drawing.Size(141, 20);
            this.end.TabIndex = 14;
            // 
            // logo
            // 
            this.logo.BackgroundImage = global::session1.Properties.Resources.wsrlogo_01;
            this.logo.Location = new System.Drawing.Point(569, 12);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(168, 74);
            this.logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logo.TabIndex = 1;
            this.logo.TabStop = false;
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(335, 249);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(100, 20);
            this.name.TabIndex = 15;
            // 
            // competition
            // 
            this.competition.FormattingEnabled = true;
            this.competition.Location = new System.Drawing.Point(208, 294);
            this.competition.Name = "competition";
            this.competition.Size = new System.Drawing.Size(121, 21);
            this.competition.TabIndex = 16;
            // 
            // expert
            // 
            this.expert.FormattingEnabled = true;
            this.expert.Location = new System.Drawing.Point(355, 294);
            this.expert.Name = "expert";
            this.expert.Size = new System.Drawing.Size(121, 21);
            this.expert.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(209, 252);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "Название чемпионата";
            // 
            // add
            // 
            this.add.BackColor = System.Drawing.Color.Blue;
            this.add.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.add.ForeColor = System.Drawing.Color.White;
            this.add.Location = new System.Drawing.Point(212, 154);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(119, 40);
            this.add.TabIndex = 21;
            this.add.Text = "Добавить";
            this.add.UseVisualStyleBackColor = false;
            // 
            // edit
            // 
            this.edit.BackColor = System.Drawing.Color.Blue;
            this.edit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.edit.ForeColor = System.Drawing.Color.White;
            this.edit.Location = new System.Drawing.Point(355, 154);
            this.edit.Name = "edit";
            this.edit.Size = new System.Drawing.Size(121, 40);
            this.edit.TabIndex = 22;
            this.edit.Text = "Изменить";
            this.edit.UseVisualStyleBackColor = false;
            this.edit.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(624, 295);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 19;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(502, 295);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 18;
            // 
            // organizatorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.edit);
            this.Controls.Add(this.add);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.expert);
            this.Controls.Add(this.competition);
            this.Controls.Add(this.name);
            this.Controls.Add(this.end);
            this.Controls.Add(this.start);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.selectChemp);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.protocol);
            this.Controls.Add(this.expertControl);
            this.Controls.Add(this.settingChemp);
            this.Controls.Add(this.chempionat);
            this.Controls.Add(this.logo);
            this.Controls.Add(this.close);
            this.Name = "organizatorForm";
            this.Text = "technicalDirectionForm";
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button close;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.Button chempionat;
        private System.Windows.Forms.Button settingChemp;
        private System.Windows.Forms.Button expertControl;
        private System.Windows.Forms.Button protocol;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox selectChemp;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker start;
        private System.Windows.Forms.DateTimePicker end;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.ComboBox competition;
        private System.Windows.Forms.ComboBox expert;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Button edit;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
    }
}