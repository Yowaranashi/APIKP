﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorldSkillsRussia
{
    public partial class FormAvtorizaciya : Form
    {
        DataBase _dataBase = new DataBase();
        public FormAvtorizaciya()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void butLogin_Click(object sender, EventArgs e)
        {
            if (tBLogin.Text == "" || tBPassword.Text == "")
            {
                MessageBox.Show("Ошибка! Некоторые поля не заполнены.", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int PIN = 0;
            if (!int.TryParse(tBLogin.Text, out PIN))
            {
                MessageBox.Show("Ошибка! Введена строка, ожидалось число.", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            SqlDataAdapter dataAdapter = new SqlDataAdapter();
            DataTable dataTable = new DataTable();
            string query = $"select * from users_mark where PIN = '{PIN}' and [password] = '{tBPassword.Text}'";

            SqlCommand sqlCommand = new SqlCommand(query, _dataBase.getConnection());
            dataAdapter.SelectCommand = sqlCommand;
            dataAdapter.Fill(dataTable);
            if (dataTable.Rows.Count == 1)
            {
                string allInfo = "";
                foreach (DataRow row in dataTable.Rows)
                {
                    var cells = row.ItemArray;
                    foreach (var cell in cells)
                    {
                        allInfo += cell + ",";
                    }
                }
                string[] ComponentsUser = allInfo.Split(',');
                string FIO = ComponentsUser[1];
                string idRole = ComponentsUser[6];
                MessageBox.Show("Здравствуйте, " + FIO + ".", "Успех!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (!checkBRemMe.Checked)
                {
                    tBLogin.Text = "";
                    tBPassword.Text = "";
                }
                this.Hide();
                FormOrganizator fromOrgan = new FormOrganizator(FIO, idRole);
                fromOrgan.ShowDialog();
                this.Show();
            }
            else
            {
                MessageBox.Show("Пользователь не найдет.", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            
        }
    }
}

//                _dataBase.openConnection();
//                if (sqlCommand.ExecuteNonQuery() == 1)
//                {
//                    MessageBox.Show("Прошел.", "Успех!", MessageBoxButtons.OK, MessageBoxIcon.Information);
//                }
//                else
//                {
//                    MessageBox.Show("Ошибка.", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
//                }
//                _dataBase.closeConnection();
