package ru.nikita.solution;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import ru.nikita.solution.controllers.AuthController;

import java.io.IOException;

public class HelloApplication extends Application {
    private AnnotationConfigApplicationContext contex;

    @Override
    public void start(Stage stage) throws IOException {
        contex = new AnnotationConfigApplicationContext(Config.class);
        AuthController cont = contex.getBean("authController", AuthController.class);
        cont.configureScene();
        stage = contex.getBean("mainStage", Stage.class);
        stage.setHeight(800);
        stage.setWidth(1100);
        stage.setTitle("World Skills");
        stage.setScene(cont.getScene());
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}