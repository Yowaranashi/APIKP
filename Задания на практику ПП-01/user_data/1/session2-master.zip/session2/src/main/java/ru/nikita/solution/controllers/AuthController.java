package ru.nikita.solution.controllers;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.nikita.solution.entities.User;
import ru.nikita.solution.services.AuthService;

@Component
public class AuthController implements Controller {
    private AuthService authService;
    private SceneSetter sceneSetter;
    private Scene scene;

    private TextField pinField = new TextField();
    private TextField passwordField = new TextField();
    private Button loginButton = new Button();
    private CheckBox rememberMe = new CheckBox();


    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @Override
    public Scene getScene() {
        return scene;
    }

    @Override
    public boolean configureScene() {
        User user = authService.getAuthUserOrNull();
        if(user != null){
            authService.setCurrentUser(user);
            sceneSetter.setScene(SceneSetter.EXPERT_CONTROLLER);
            return false;
        } else {
            configPage();
            return true;
        }
    }

    @Override
    public int getId() {
        return 0;
    }

    @Override
    public void setSceneSetter(SceneSetter sceneSetter) {
        this.sceneSetter = sceneSetter;
    }

    private void onLoginButtonClick() {
        String pinStr = pinField.getText();
        String password = passwordField.getText();

        try {
            int pin = Integer.parseInt(pinStr);
            if(authService.hasUser(pin, password)) {
                User user = authService.getUserByPin(pin);
                authService.setCurrentUser(user);
                if(rememberMe.isSelected()) {
                    authService.rememberCurrentUser();
                }
                sceneSetter.setScene(SceneSetter.EXPERT_CONTROLLER);
            } else
                new Alert(Alert.AlertType.WARNING, "Такого пользователя не найдено!").show();
        }catch (Exception e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.WARNING, "Некорректные данные!").show();
        }
    }

    private void configPage() {
        AnchorPane anchor = new AnchorPane();
        Label pinLabel = configPinTextField();
        Label passwordLabel = configPasswordTextField();
        configButton();
        configRememberMe();
        anchor.getChildren().addAll(pinField, pinLabel, passwordField, passwordLabel, loginButton, rememberMe);
        scene = new Scene(anchor);
    }

    private void configRememberMe() {
        rememberMe.setText("Запомнить меня");
        rememberMe.setTranslateX(450);
        rememberMe.setTranslateY(343);

    }

    private Label configPasswordTextField() {
        passwordField.setTranslateX(450);
        passwordField.setTranslateY(300);
        passwordField.setPrefHeight(40);
        passwordField.setPrefWidth(175);


        Label passwordLabel = new Label();
        passwordLabel.setText("Пароль");
        passwordLabel.setFont(Font.font(20));
        passwordLabel.setLabelFor(pinField);
        passwordLabel.setTranslateX(350);
        passwordLabel.setTranslateY(300);
        passwordLabel.setPrefHeight(30);
        passwordLabel.setPrefWidth(100);

        return passwordLabel;
    }

    private Label configPinTextField() {
        pinField.setTranslateX(450);
        pinField.setTranslateY(250);
        pinField.setPrefHeight(40);
        pinField.setPrefWidth(175);

        Label pinLabel = new Label();
        pinLabel.setText("Логин");
        pinLabel.setFont(Font.font(20));
        pinLabel.setLabelFor(pinField);
        pinLabel.setTranslateX(350);
        pinLabel.setTranslateY(250);
        pinLabel.setPrefHeight(30);
        pinLabel.setPrefWidth(100);

        return pinLabel;
    }

    private void configButton() {
        loginButton.setTranslateX(470);
        loginButton.setTranslateY(370);
        loginButton.setPrefHeight(30);
        loginButton.setPrefWidth(100);
        loginButton.setText("Логин");
        loginButton.setOnMouseClicked(e -> onLoginButtonClick());
    }
}