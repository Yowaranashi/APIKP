package ru.nikita.solution;

import javafx.stage.Stage;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import ru.nikita.solution.controllers.AuthController;
import ru.nikita.solution.daos.AuthDAO;
import ru.nikita.solution.daos.AuthDAOImp;
import ru.nikita.solution.daos.DAO;
import ru.nikita.solution.entities.*;
import ru.nikita.solution.util.SessionInvocationHandler;

import java.lang.reflect.Proxy;

@org.springframework.context.annotation.Configuration
@ComponentScan
public class Config {
    @Bean
    public SessionFactory sessionFactory() {
        Configuration configuration = new Configuration();
        addAnnotatedClasses(configuration);
        return configuration.buildSessionFactory();
    }

    @Bean
    public Stage mainStage() {
        return new Stage();
    }

    @Bean
    public AuthDAO authDAO() {
        AuthDAO authDAO = new AuthDAOImp();

        return (AuthDAO) createProxyForDAO(authDAO);
    }

    private <T extends DAO> DAO createProxyForDAO(T dao) {
        Class<? extends DAO> daoClass =  dao.getClass();

        return (DAO) Proxy.newProxyInstance(daoClass.getClassLoader(), daoClass.getInterfaces(),
                                        new SessionInvocationHandler(dao, sessionFactory()));
    }

    private void addAnnotatedClasses(Configuration configuration) {
        configuration.addAnnotatedClass(User.class)
                .addAnnotatedClass(Competition.class)
                .addAnnotatedClass(Region.class)
                .addAnnotatedClass(Role.class)
                .addAnnotatedClass(Skill.class)
                .addAnnotatedClass(SkillBlock.class);
    }
}
