package ru.nikita.solution.controllers;

import javafx.stage.Stage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Класс отвечает за смену сцен в оконном приложении
 * В параметры передается само окно(Stage) и контроллеры всех окон, каждый их которых имеет совй id
 */
@Component
public class SceneSetter {
    public static final int AUTH_CONTROLLER = 0;
    public static final int EXPERT_CONTROLLER = 1;

    private Map<Integer, Controller> controllers;

    private Stage stage;

    @Autowired
    public SceneSetter(Stage stage, List<Controller> allControllers) {
        this.stage = stage;
        controllers = new HashMap<>();
        allControllers.forEach(c -> {
                                        c.setSceneSetter(this);
                                        controllers.put(c.getId(), c);
                                    });
    }

    public void setScene(int controllerId) {
        Controller controller = controllers.get(controllerId);
        if(controller.configureScene())
            stage.setScene(controller.getScene());
    }
}
