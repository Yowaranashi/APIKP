package ru.nikita.solution.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.Objects;

@Entity
@Table(name="regions")
public class Region {
    @Id
    @Column(name="код")
    private int id;

    @Column(name="название_региона")
    private String region;

    @Column(name="округ")
    private String okrug;

    @Column(name="столица")
    private String stolica;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getOkrug() {
        return okrug;
    }

    public void setOkrug(String okrug) {
        this.okrug = okrug;
    }

    public String getStolica() {
        return stolica;
    }

    public void setStolica(String stolica) {
        this.stolica = stolica;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Region region1 = (Region) o;
        return id == region1.id && Objects.equals(region, region1.region) && Objects.equals(okrug, region1.okrug) && Objects.equals(stolica, region1.stolica);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, region, okrug, stolica);
    }
}
