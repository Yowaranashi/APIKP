package ru.nikita.solution.daos;

import org.hibernate.Session;

public interface DAO {
    Session getCurrentSession();

    void setCurrentSession(Session currentSession);
}
