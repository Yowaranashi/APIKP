package ru.nikita.solution.entities;

import jakarta.persistence.*;

import java.util.Objects;

@Table(name="skill")
@Entity
public class Skill {
    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name="title")
    private String title;

    @ManyToOne
    @JoinColumn(name="skill_block_id", referencedColumnName="id")
    private SkillBlock skillBlock;

    @Column(name="description")
    private String description;

    @Column(name="try_a_skill_square")
    private int trySkillsSquare;

    @Column(name="work_square")
    private int workSquare;

    @Column(name="expert_square")
    private int expertSquare;

    @Column(name="briffing_square")
    private int briefingSquare;

    @Column(name="square_sclade")
    private int scladeSquare;

    @Column(name="count_of_players")
    private int countOfParticiant;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public SkillBlock getSkillBlock() {
        return skillBlock;
    }

    public void setSkillBlock(SkillBlock skillBlock) {
        this.skillBlock = skillBlock;
    }

    public int getTrySkillsSquare() {
        return trySkillsSquare;
    }

    public void setTrySkillsSquare(int trySkillsSquare) {
        this.trySkillsSquare = trySkillsSquare;
    }

    public int getWorkSquare() {
        return workSquare;
    }

    public void setWorkSquare(int workSquare) {
        this.workSquare = workSquare;
    }

    public int getExpertSquare() {
        return expertSquare;
    }

    public void setExpertSquare(int expertSquare) {
        this.expertSquare = expertSquare;
    }

    public int getBriefingSquare() {
        return briefingSquare;
    }

    public void setBriefingSquare(int briefingSquare) {
        this.briefingSquare = briefingSquare;
    }

    public int getScladeSquare() {
        return scladeSquare;
    }

    public void setScladeSquare(int scladeSquare) {
        this.scladeSquare = scladeSquare;
    }

    public int getCountOfParticiant() {
        return countOfParticiant;
    }

    public void setCountOfParticiant(int countOfParticiant) {
        this.countOfParticiant = countOfParticiant;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Skill skill = (Skill) o;
        return id == skill.id && trySkillsSquare == skill.trySkillsSquare && workSquare == skill.workSquare && expertSquare == skill.expertSquare && briefingSquare == skill.briefingSquare && scladeSquare == skill.scladeSquare && countOfParticiant == skill.countOfParticiant && Objects.equals(title, skill.title) && Objects.equals(skillBlock, skill.skillBlock);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, title, skillBlock, trySkillsSquare, workSquare, expertSquare, briefingSquare, scladeSquare, countOfParticiant);
    }
}
