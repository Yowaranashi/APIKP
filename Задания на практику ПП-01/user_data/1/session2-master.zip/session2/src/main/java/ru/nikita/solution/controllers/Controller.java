package ru.nikita.solution.controllers;

import javafx.scene.Scene;

/**
 * Классы, рееализующие данный интерфейс отвечают за отображение сцен.
 * Присутствует API для кореетной настройки каждой сцены пред добавлением в Stage
 */
public interface Controller {

    /**
     * @return  возвращает сцену, за которую отввечает контроллер
     */
    Scene getScene();

    /**
     * Возвращает id пароял (id нужен для коректной работы SceneSetter`a)
     * который уникален для каждого котроллера
     */
    int getId();

    /**
     * Конфигурирует сцену перед тем, как поставитель ее (обязательно вызывать перед первым вызовом метода getScene()
     * @return true - если конфигурация успешна и можно вызывать setScene(),
     * @return false - если нельзя вызывать setScene(), возвращать при неудачном кофигурированиемЮ либо если было пердано управление дургому контроллеру
     */
    boolean configureScene();

    /**
     * метод устанавливате SceneSetter в контроллере
     */
    void setSceneSetter(SceneSetter sceneSetter);
}
