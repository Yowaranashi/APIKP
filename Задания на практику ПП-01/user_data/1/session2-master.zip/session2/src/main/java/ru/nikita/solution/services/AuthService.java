package ru.nikita.solution.services;

import org.springframework.stereotype.Service;
import ru.nikita.solution.daos.AuthDAO;
import ru.nikita.solution.entities.User;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

@Service
public class AuthService {
    private AuthDAO authDAO;
    /**
     * Текущий авторизованный пользователь
     */
    private User currentUser;

    public AuthService(AuthDAO authDAO) {
        this.authDAO = authDAO;
    }

    /**
     * Проверяет, есть ли в БД пользователь с таким пином и паролем
     * @return true - если есть, false - иначе*/
    public boolean hasUser(int pin, String password) {
        return authDAO.hasUser(pin, password);
    }

    public User getUserByPin(int pin) {
        return authDAO.getUserByPin(pin);
    }

    /**
     * Запоминание пользователя на данном компьютере
     */
    public void rememberCurrentUser() {
     try{
         Properties props = new Properties();
         props.setProperty("nikita.ru.pin", String.valueOf(currentUser.getPin()));
         props.setProperty("nikita.ru.password", currentUser.getPassword());
         props.store(new FileOutputStream(getClass().getClassLoader().getResource("remembereduser.properties").getFile()),"");
    }catch (IOException e) {
        e.printStackTrace();
    }

    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }

    /**
     * Удаление аунтефицированного пользователь на данном компьютере
     */
    public void logout() {
        try{
            currentUser = null;
            Properties props = new Properties();
            props.setProperty("nikita.ru.pin", "");
            props.setProperty("nikita.ru.password", "");
            props.store(new FileOutputStream(getClass().getClassLoader().getResource("remembereduser.properties").getFile()),"");
        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Проверяет, есть ли аунтефицированный пользователь на этом компьютере или
     * @return обьект User если есть, null - иначе
     **/
    public User getAuthUserOrNull() {
        Properties props = new Properties();
        try {
            props.load(getClass().getClassLoader().getResourceAsStream("remembereduser.properties"));
        }catch (IOException e) {
            e.printStackTrace();
        }
        String pinStr = props.getProperty("nikita.ru.pin");
        String password = props.getProperty("nikita.ru.password");

        int pin;
        try {
            pin = Integer.parseInt(pinStr);
        }catch (Exception e){
            return null;
        }

        if(password == null || password.isEmpty() || authDAO.hasUser(pin, password)) {
            return null;
        }

        return authDAO.getUserByPin(pin);
    }
}
