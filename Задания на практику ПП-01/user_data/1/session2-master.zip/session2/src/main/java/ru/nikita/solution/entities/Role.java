package ru.nikita.solution.entities;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name="role")
public class Role {
    public final static String PARTICIANT ="Участник";
    public final static String EXPERT ="Эксперт";
    public final static String MAIN_EXPERT ="Главный эксперт";
    public final static String EXPERT_PROXY ="Заместитель главного эксперта";
    public final static String TEXHICAL_EXPERT ="Технический эксперт";
    public final static String ORGANIZATOR ="Организатор";

    @Id
    @Column(name="id")
    private int id;

    @Column(name="role")
    private String role;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Role role1 = (Role) o;
        return id == role1.id && Objects.equals(role, role1.role);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, role);
    }
}
