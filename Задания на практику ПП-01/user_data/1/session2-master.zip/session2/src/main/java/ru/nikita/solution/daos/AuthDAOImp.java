package ru.nikita.solution.daos;

import org.hibernate.Session;
import ru.nikita.solution.entities.User;

public class AuthDAOImp implements AuthDAO {
    private Session currentSession;

    @Override
    public boolean hasUser(int pin, String password) {
        return !currentSession.createNativeQuery("SELECT * FROM user WHERE user.pin = ? AND user.password = ?", User.class)
                .setParameter(1, pin)
                .setParameter(2, password)
                .getResultList().isEmpty();
    }

    @Override
    public User getUserByPin(int pin) {
        return currentSession.createNativeQuery("SELECT * FROM user WHERE user.pin = ?", User.class)
                                   .setParameter(1, pin)
                                   .getSingleResult();
    }

    public Session getCurrentSession() {
        return currentSession;
    }

    public void setCurrentSession(Session currentSession) {
        this.currentSession = currentSession;
    }
}
