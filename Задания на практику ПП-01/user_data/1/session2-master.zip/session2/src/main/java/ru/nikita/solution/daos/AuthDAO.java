package ru.nikita.solution.daos;

import ru.nikita.solution.entities.User;

public interface AuthDAO extends DAO{
    /**
     * Метод проверяет есть ли в базе пользователь с такими данными
     * @param pin логин(pin) пользователс
     * @param password пароль пользователя
     * @return true - если есть, иначе - flase
     */
    boolean hasUser(int pin, String password);

    /**
     * @return Возвращает роль польлзователя
     * @param pin логин по которому ищется пользователь для определения роли
     */
    User getUserByPin(int pin);


}
