package ru.nikita.solution.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import ru.nikita.solution.daos.DAO;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class SessionInvocationHandler implements InvocationHandler {

    private DAO dao;
    private SessionFactory sessionFactory;

    public SessionInvocationHandler(DAO dao, SessionFactory sessionFactory) {
        this.dao = dao;
        this.sessionFactory = sessionFactory;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        Session session = null;
        try {
            while(dao.getCurrentSession() != null);

            session = sessionFactory.openSession();
            dao.setCurrentSession(session);
            session.beginTransaction();
            Object result = method.invoke(dao, args);
            session.getTransaction().commit();

            dao.setCurrentSession(null);

            return result;
        } catch (Throwable e) {
            if(session != null)
                session.getTransaction().rollback();
            throw e;
        }
    }
}
