package ru.nikita.solution.controllers;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.nikita.solution.HelloApplication;
import ru.nikita.solution.entities.Role;
import ru.nikita.solution.entities.User;
import ru.nikita.solution.services.AuthService;

import java.util.Date;
import java.util.List;

@Component
public class ExpertWindowController implements UserWindowController {
    private AuthService authService;
    private SceneSetter sceneSetter;
    private User user;

    private Scene scene;
    private Button exitBt = new Button("Выход");
    private Label competitionLabel = new Label();
    private Label helloLabel = new Label();

    private Button particiantBt = new Button("Список учатсников");
    private Button expertBt = new Button("Список экспертов");
    private Button protocolsBt = new Button("Протоколы");
    private ImageView logo;


    public ExpertWindowController(AuthService authService) {
        this.authService = authService;
    }

    @Override
    public boolean configureScene() {
        configurePage();
        return true;
    }

    @Override
    public Scene getScene() {
        return scene;
    }

    @Override
    public int getId() {
        return SceneSetter.EXPERT_CONTROLLER;
    }

    @Override
    public List<String> forRoles() {
        return List.of(Role.EXPERT, Role.MAIN_EXPERT, Role.EXPERT_PROXY, Role.TEXHICAL_EXPERT);
    }

    private void configurePage() {
        user = authService.getCurrentUser();

        AnchorPane pane = new AnchorPane();
        exitBt.setTranslateY(5);
        exitBt.setTranslateX(5);

        helloLabel.setTranslateY(30);
        helloLabel.setTranslateX(5);
        helloLabel.setText("Добрый день " + user.getFullName() + "\nДень " + getDay());

        particiantBt.setTranslateX(5);
        particiantBt.setTranslateY(100);
        expertBt.setTranslateX(5);
        expertBt.setTranslateY(150);
        protocolsBt.setTranslateX(5);
        protocolsBt.setTranslateY(200);

        logo = new ImageView(new Image(HelloApplication.class.getClassLoader().getResourceAsStream("logo.png")));
        logo.setX(900);
        logo.setY(50);
        logo.setFitHeight(100);
        logo.setFitWidth(100);


        pane.getChildren().addAll(exitBt, competitionLabel, helloLabel, particiantBt, expertBt,protocolsBt, logo);
        scene = new Scene(pane);


    }

    public void setSceneSetter(SceneSetter sceneSetter) {
        this.sceneSetter = sceneSetter;
    }

    private String getDay() {
        int compStartfday = user.getCompetition().getStartDate().getDay();
        int curDay = new Date().getDay();
        int defference = curDay-compStartfday;
        if(defference == 0)
            return "C-1";
        else if(defference == 1)
            return "C1";
        else if(defference == 2)
            return "C1";
        else if(defference == 3)
            return "C2";
        else if(defference == 4)
            return "C+1";
        else
            return null;
    }

}
