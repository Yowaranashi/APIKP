package ru.nikita.solution.controllers;

import ru.nikita.solution.entities.Role;

import java.util.List;

/**
 * Контороллер нужный для */
public interface UserWindowController extends Controller {
    List<String> forRoles();
}
