package ru.nikita.solution.controllers;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

public class AuthController implements Controller {
    private Scene scene;

    private TextField pin = new TextField();
    private TextField password = new TextField();
    private Button loginButton = new Button();


    public AuthController(){}

    @Override
    public Scene getScene() {
        return scene;
    }

    @Override
    public int getId() {
        return 0;
    }
}
