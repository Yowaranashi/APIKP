package ru.nikita.solution;

import javafx.stage.Stage;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import ru.nikita.solution.controllers.AuthController;
import ru.nikita.solution.entities.*;

@org.springframework.context.annotation.Configuration
@ComponentScan
public class Config {
    @Bean
    public SessionFactory sessionFactory() {
        Configuration configuration = new Configuration().addAnnotatedClass(User.class);

        return configuration.buildSessionFactory();
    }

    @Bean
    public Stage mainStage() {
        return new Stage();
    }

    public AuthController authController() {
        return new AuthController();
    }
}
