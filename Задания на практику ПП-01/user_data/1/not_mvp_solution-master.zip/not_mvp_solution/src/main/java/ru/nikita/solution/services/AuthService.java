package ru.nikita.solution.services;

public class AuthService {
}
