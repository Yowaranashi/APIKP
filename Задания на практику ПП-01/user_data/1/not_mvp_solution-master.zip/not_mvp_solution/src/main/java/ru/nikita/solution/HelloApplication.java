package ru.nikita.solution;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.io.IOException;

public class HelloApplication extends Application {
    private AnnotationConfigApplicationContext contex;

    @Override
    public void start(Stage stage) throws IOException {
        contex = new AnnotationConfigApplicationContext(Config.class);
        stage = contex.getBean("mainStage", Stage.class);
        stage.setHeight(500);
        stage.setWidth(600);
        stage.setTitle("Hello!");
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}