module ru.nikita.solution {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires eu.hansolo.tilesfx;
    requires org.hibernate.orm.core;
    requires java.naming;
    requires mysql.connector.j;
    requires java.sql;
    requires jakarta.persistence;
    requires spring.beans;
    requires spring.core;
    requires spring.context;

    opens ru.nikita.solution to javafx.fxml, org.hibernate.orm.core, spring.beans, spring.core, spring.context;
    opens ru.nikita.solution.entities to org.hibernate.orm.core;
    exports ru.nikita.solution;
    exports ru.nikita.solution.entities;
}