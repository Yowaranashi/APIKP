package ru.nikita.solution.controllers;

import ru.nikita.solution.entities.Role;

import java.util.List;

public interface UserController extends Controller {
    List<Role> forRoles();
}
