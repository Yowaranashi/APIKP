package ru.nikita.solution.controllers;

import javafx.scene.Scene;

public interface Controller {

    /**
     * @return  возвращает сцену, за которую отввечает контроллер
     */
    Scene getScene();

    /**
     * Возвращает id пароял (id нужен для коректной работы SceneSetter`a)
     */
    int getId();
}
