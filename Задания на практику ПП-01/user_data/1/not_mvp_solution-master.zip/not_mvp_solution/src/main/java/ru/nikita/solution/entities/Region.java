package ru.nikita.solution.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Id;

public class Region {
    @Id
    @Column(name="id")
    private int id;

    @Column(name="name")
    private String name;
}
