package ru.nikita.solution.entities;

import jakarta.persistence.*;

public enum Role {
    PLAYER,
    EXPERT,
    MAIN_EXPERT,
    PROXY_MAIN_EXPERT,
    ORGANIZATOR
}
