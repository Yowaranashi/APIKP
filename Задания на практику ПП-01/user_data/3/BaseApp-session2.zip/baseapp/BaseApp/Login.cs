﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BaseApp
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = @" Data Source=WM-SQL-SERVER\SQLEXPRESS01;user ID=bsn_user3;Password=PyMZQH;Connect Timeout=30;Encrypt=False;Initial catalog=db_bsn_user3";

                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDel = $" Select count(*) from users where PIN={LoginTextBox.Text} and password ='{PasswordTextBox.Text}' and [ID role] = 6";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);

                MyConnection.Open();
                string count = cmd1.ExecuteScalar().ToString();
                MyConnection.Close();


                if (Convert.ToInt32(count) != 0)
                {
                    Main main = new Main(connectionString, this);
                    main.ShowDialog();
                    LoginButton.Enabled = false;
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
