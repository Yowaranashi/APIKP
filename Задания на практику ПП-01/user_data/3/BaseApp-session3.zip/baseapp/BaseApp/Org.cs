﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaseApp
{
    public partial class Org : Form
    {
        public Org(string connectionString, Login login)
        {
            InitializeComponent();
            _connectionString = connectionString;
            this._login = login;
        }

        private string _connectionString;
        private Login _login;
        private SqlConnection MyConnection;

        private void Main_Load(object sender, EventArgs e)
        {

            try
            {
                ChempComboBox.SelectedIndex = 0;

                MyConnection = new SqlConnection(_connectionString);
                MyConnection.Open();

                string ComDel = $"select title from competition where date_start > (GETDATE() - day(30))";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);

                var Reader = cmd1.ExecuteReader();
                while (Reader.Read())
                {
                    ChempComboBox.Items.Add(Reader[0].ToString());
                }
                Reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }



        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            _login.Close();
            MyConnection.Close();
        }

        private void ChempComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ChempComboBox.SelectedIndex != 0)
            {
                Chemp chemp = new Chemp(_connectionString, this, ChempComboBox.Text);
                chemp.ShowDialog();
            }
        }
    }
}
