﻿namespace BaseApp
{
    partial class Org
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ChempButton = new System.Windows.Forms.Button();
            this.SettingsButton = new System.Windows.Forms.Button();
            this.ExpertButton = new System.Windows.Forms.Button();
            this.ProtocolButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.HelloLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ChempComboBox = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // ChempButton
            // 
            this.ChempButton.Location = new System.Drawing.Point(27, 177);
            this.ChempButton.Name = "ChempButton";
            this.ChempButton.Size = new System.Drawing.Size(124, 38);
            this.ChempButton.TabIndex = 0;
            this.ChempButton.Text = "Чемпионат";
            this.ChempButton.UseVisualStyleBackColor = true;
            // 
            // SettingsButton
            // 
            this.SettingsButton.Location = new System.Drawing.Point(27, 226);
            this.SettingsButton.Name = "SettingsButton";
            this.SettingsButton.Size = new System.Drawing.Size(124, 38);
            this.SettingsButton.TabIndex = 1;
            this.SettingsButton.Text = "Настройки чемпионата";
            this.SettingsButton.UseVisualStyleBackColor = true;
            // 
            // ExpertButton
            // 
            this.ExpertButton.Location = new System.Drawing.Point(27, 275);
            this.ExpertButton.Name = "ExpertButton";
            this.ExpertButton.Size = new System.Drawing.Size(124, 38);
            this.ExpertButton.TabIndex = 2;
            this.ExpertButton.Text = "Управление экспертами";
            this.ExpertButton.UseVisualStyleBackColor = true;
            // 
            // ProtocolButton
            // 
            this.ProtocolButton.Location = new System.Drawing.Point(27, 325);
            this.ProtocolButton.Name = "ProtocolButton";
            this.ProtocolButton.Size = new System.Drawing.Size(124, 38);
            this.ProtocolButton.TabIndex = 3;
            this.ProtocolButton.Text = "Протоколы";
            this.ProtocolButton.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(194, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(181, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Техническая дирекция";
            // 
            // HelloLabel
            // 
            this.HelloLabel.AutoSize = true;
            this.HelloLabel.Location = new System.Drawing.Point(198, 53);
            this.HelloLabel.Name = "HelloLabel";
            this.HelloLabel.Size = new System.Drawing.Size(129, 13);
            this.HelloLabel.TabIndex = 5;
            this.HelloLabel.Text = "Доброго времени суток";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(42, 29);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Выход";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(201, 117);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(532, 295);
            this.dataGridView1.TabIndex = 8;
            // 
            // ChempComboBox
            // 
            this.ChempComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ChempComboBox.FormattingEnabled = true;
            this.ChempComboBox.Items.AddRange(new object[] {
            "Чемпионат"});
            this.ChempComboBox.Location = new System.Drawing.Point(27, 81);
            this.ChempComboBox.Name = "ChempComboBox";
            this.ChempComboBox.Size = new System.Drawing.Size(242, 21);
            this.ChempComboBox.TabIndex = 9;
            this.ChempComboBox.SelectedIndexChanged += new System.EventHandler(this.ChempComboBox_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::BaseApp.Properties.Resources.wsrlogo_01;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(619, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(106, 67);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // Org
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ChempComboBox);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.HelloLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ProtocolButton);
            this.Controls.Add(this.ExpertButton);
            this.Controls.Add(this.SettingsButton);
            this.Controls.Add(this.ChempButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Org";
            this.Text = "Main";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Main_FormClosing);
            this.Load += new System.EventHandler(this.Main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ChempButton;
        private System.Windows.Forms.Button SettingsButton;
        private System.Windows.Forms.Button ExpertButton;
        private System.Windows.Forms.Button ProtocolButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label HelloLabel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox ChempComboBox;
    }
}