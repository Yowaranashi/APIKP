﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaseApp
{
    public partial class Chemp : Form
    {
        public Chemp(string connectionString, Org main, string examName)
        {
            InitializeComponent();
            _connectionString = connectionString;
            this._main = main;
            this._examName = examName;
        }

        private string _connectionString;
        private Org _main;
        private string _examName;
        private SqlConnection MyConnection;

        private void DataClear()
        {
            MainExpertsDataGridView.Rows.Clear();
            MainExpertsDataGridView.Columns.Clear();
        }

        private void ExpertButton_Click(object sender, EventArgs e)
        {
            MainExpertsDataGridView.Visible = true;
            ExpertListPanel.Visible = false;
            SaveButton.Visible = false;
            ChempSettingsTabControl.Visible = false;

            try
            {
                DataClear();

                MainExpertsDataGridView.ColumnCount = 6;
                MainExpertsDataGridView.Columns[0].Name = "Порядковый номер";
                MainExpertsDataGridView.Columns[1].Name = "ФИО эксперта";
                MainExpertsDataGridView.Columns[2].Name = "роль";
                MainExpertsDataGridView.Columns[3].Name = "компетенция";
                MainExpertsDataGridView.Columns[4].Name = "телефон";
                MainExpertsDataGridView.Columns[5].Name = "email";
                MainExpertsDataGridView.RowCount = 1;



                string ComDel = $"select id, fio, [ID role], skill, telephone, email from users where [ID role] in (2, 3, 4, 5)";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);

                var Reader = cmd1.ExecuteReader();


                while (Reader.Read())
                {
                    MainExpertsDataGridView.Rows.Add(Reader[0].ToString(), Reader[1].ToString(), Reader[2].ToString(), Reader[3].ToString(), Reader[4].ToString(), Reader[5].ToString());
                }
                Reader.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error); }

        }

        private void PersonsButton_Click(object sender, EventArgs e)
        {
            MainExpertsDataGridView.Visible = false;
            ExpertListPanel.Visible = true;
            SaveButton.Visible = false;
            ChempSettingsTabControl.Visible = false;
        }


        private void Chemp_Load(object sender, EventArgs e)
        {
            ChempNameLabel.Text = _examName;
            MyConnection = new SqlConnection(_connectionString);
            MyConnection.Open();
        }

        private void Chemp_FormClosing(object sender, FormClosingEventArgs e)
        {
            MyConnection.Close();
        }

        private void SettingsButton_Click(object sender, EventArgs e)
        {
            MainExpertsDataGridView.Visible = false;
            ExpertListPanel.Visible = false;
            SaveButton.Visible = true;
            ChempSettingsTabControl.Visible = true;
        }
    }
}
