﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaseApp
{
    public partial class Person : Form
    {
        public Person(string connectionString, Login login, string skill)
        {
            InitializeComponent();
            _connectionString = connectionString;
            this._login = login;
            _skill = skill;
        }

        private string _connectionString;
        private Login _login;
        private SqlConnection MyConnection;
        private int _chempID;
        private string _skill;


        private void Person_Load(object sender, EventArgs e)
        {

            try
            {
                MyConnection = new SqlConnection(_connectionString);
                MyConnection.Open();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        private bool _exitFlag = false;

        private void Person_FormClosing(object sender, FormClosingEventArgs e)
        {
            MyConnection.Close();
            if (!_exitFlag)
            {
                _login.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            _exitFlag = true;
            this.Close();
        }
    }
}
