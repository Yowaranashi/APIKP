﻿namespace BaseApp
{
    partial class Expert
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PersonListButton = new System.Windows.Forms.Button();
            this.ExpertsListButton = new System.Windows.Forms.Button();
            this.ProtocolButton = new System.Windows.Forms.Button();
            this.CempNameLabel = new System.Windows.Forms.Label();
            this.SkillLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.AuCodeTextBox = new System.Windows.Forms.TextBox();
            this.ListPanel = new System.Windows.Forms.Panel();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.SaveButton = new System.Windows.Forms.Button();
            this.EditButton = new System.Windows.Forms.Button();
            this.AddButton = new System.Windows.Forms.Button();
            this.FixListButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.ProtocolPanel = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.ListPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.ProtocolPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // PersonListButton
            // 
            this.PersonListButton.Location = new System.Drawing.Point(12, 174);
            this.PersonListButton.Name = "PersonListButton";
            this.PersonListButton.Size = new System.Drawing.Size(141, 27);
            this.PersonListButton.TabIndex = 0;
            this.PersonListButton.Text = "Список учасников";
            this.PersonListButton.UseVisualStyleBackColor = true;
            this.PersonListButton.Click += new System.EventHandler(this.PersonListButton_Click);
            // 
            // ExpertsListButton
            // 
            this.ExpertsListButton.Location = new System.Drawing.Point(12, 223);
            this.ExpertsListButton.Name = "ExpertsListButton";
            this.ExpertsListButton.Size = new System.Drawing.Size(141, 27);
            this.ExpertsListButton.TabIndex = 1;
            this.ExpertsListButton.Text = "Список экспертов";
            this.ExpertsListButton.UseVisualStyleBackColor = true;
            this.ExpertsListButton.Click += new System.EventHandler(this.ExpertsListButton_Click);
            // 
            // ProtocolButton
            // 
            this.ProtocolButton.Location = new System.Drawing.Point(12, 279);
            this.ProtocolButton.Name = "ProtocolButton";
            this.ProtocolButton.Size = new System.Drawing.Size(141, 27);
            this.ProtocolButton.TabIndex = 3;
            this.ProtocolButton.Text = "Протоколы";
            this.ProtocolButton.UseVisualStyleBackColor = true;
            this.ProtocolButton.Click += new System.EventHandler(this.ProtocolButton_Click);
            // 
            // CempNameLabel
            // 
            this.CempNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CempNameLabel.Location = new System.Drawing.Point(194, 29);
            this.CempNameLabel.Name = "CempNameLabel";
            this.CempNameLabel.Size = new System.Drawing.Size(389, 35);
            this.CempNameLabel.TabIndex = 4;
            this.CempNameLabel.Text = "Наименование чемпионата";
            // 
            // SkillLabel
            // 
            this.SkillLabel.AutoSize = true;
            this.SkillLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SkillLabel.Location = new System.Drawing.Point(195, 64);
            this.SkillLabel.Name = "SkillLabel";
            this.SkillLabel.Size = new System.Drawing.Size(87, 15);
            this.SkillLabel.TabIndex = 5;
            this.SkillLabel.Text = "Компетенция";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(42, 29);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Выход";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::BaseApp.Properties.Resources.wsrlogo_01;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(619, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(106, 67);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Доброго времени суток";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(309, 415);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Ваш код доступа на сегодня: ";
            // 
            // AuCodeTextBox
            // 
            this.AuCodeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AuCodeTextBox.Location = new System.Drawing.Point(472, 408);
            this.AuCodeTextBox.Multiline = true;
            this.AuCodeTextBox.Name = "AuCodeTextBox";
            this.AuCodeTextBox.ReadOnly = true;
            this.AuCodeTextBox.Size = new System.Drawing.Size(111, 30);
            this.AuCodeTextBox.TabIndex = 11;
            this.AuCodeTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ListPanel
            // 
            this.ListPanel.Controls.Add(this.DeleteButton);
            this.ListPanel.Controls.Add(this.SaveButton);
            this.ListPanel.Controls.Add(this.EditButton);
            this.ListPanel.Controls.Add(this.AddButton);
            this.ListPanel.Controls.Add(this.FixListButton);
            this.ListPanel.Controls.Add(this.dataGridView1);
            this.ListPanel.Location = new System.Drawing.Point(189, 108);
            this.ListPanel.Name = "ListPanel";
            this.ListPanel.Size = new System.Drawing.Size(564, 294);
            this.ListPanel.TabIndex = 12;
            this.ListPanel.Visible = false;
            // 
            // DeleteButton
            // 
            this.DeleteButton.Location = new System.Drawing.Point(455, 224);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(100, 23);
            this.DeleteButton.TabIndex = 2;
            this.DeleteButton.Text = "Удалить";
            this.DeleteButton.UseVisualStyleBackColor = true;
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(236, 260);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(100, 23);
            this.SaveButton.TabIndex = 2;
            this.SaveButton.Text = "Сохранить";
            this.SaveButton.UseVisualStyleBackColor = true;
            // 
            // EditButton
            // 
            this.EditButton.Location = new System.Drawing.Point(115, 224);
            this.EditButton.Name = "EditButton";
            this.EditButton.Size = new System.Drawing.Size(100, 23);
            this.EditButton.TabIndex = 2;
            this.EditButton.Text = "Изменить";
            this.EditButton.UseVisualStyleBackColor = true;
            // 
            // AddButton
            // 
            this.AddButton.Location = new System.Drawing.Point(9, 224);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(100, 23);
            this.AddButton.TabIndex = 2;
            this.AddButton.Text = "Добавить";
            this.AddButton.UseVisualStyleBackColor = true;
            // 
            // FixListButton
            // 
            this.FixListButton.Location = new System.Drawing.Point(416, 10);
            this.FixListButton.Name = "FixListButton";
            this.FixListButton.Size = new System.Drawing.Size(139, 23);
            this.FixListButton.TabIndex = 1;
            this.FixListButton.Text = "Зафиксировать список";
            this.FixListButton.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(9, 48);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.Size = new System.Drawing.Size(546, 170);
            this.dataGridView1.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "День с-1";
            // 
            // ProtocolPanel
            // 
            this.ProtocolPanel.Controls.Add(this.button11);
            this.ProtocolPanel.Controls.Add(this.button6);
            this.ProtocolPanel.Controls.Add(this.button10);
            this.ProtocolPanel.Controls.Add(this.button5);
            this.ProtocolPanel.Controls.Add(this.button9);
            this.ProtocolPanel.Controls.Add(this.button4);
            this.ProtocolPanel.Controls.Add(this.button8);
            this.ProtocolPanel.Controls.Add(this.button3);
            this.ProtocolPanel.Controls.Add(this.button7);
            this.ProtocolPanel.Controls.Add(this.button2);
            this.ProtocolPanel.Location = new System.Drawing.Point(175, 111);
            this.ProtocolPanel.Name = "ProtocolPanel";
            this.ProtocolPanel.Size = new System.Drawing.Size(595, 291);
            this.ProtocolPanel.TabIndex = 14;
            this.ProtocolPanel.Visible = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Control;
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(23, 63);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(155, 23);
            this.button2.TabIndex = 0;
            this.button2.Text = "День С-2";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.Control;
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(23, 94);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(155, 23);
            this.button3.TabIndex = 0;
            this.button3.Text = "День С-1";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.Control;
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(23, 123);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(155, 23);
            this.button4.TabIndex = 0;
            this.button4.Text = "День С1";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.Control;
            this.button5.ForeColor = System.Drawing.Color.Black;
            this.button5.Location = new System.Drawing.Point(23, 152);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(155, 23);
            this.button5.TabIndex = 0;
            this.button5.Text = "День С2";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.Control;
            this.button6.ForeColor = System.Drawing.Color.Black;
            this.button6.Location = new System.Drawing.Point(23, 181);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(155, 23);
            this.button6.TabIndex = 0;
            this.button6.Text = "День С1+1";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.Control;
            this.button7.ForeColor = System.Drawing.Color.Black;
            this.button7.Location = new System.Drawing.Point(195, 63);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(383, 23);
            this.button7.TabIndex = 0;
            this.button7.Text = "Регистрация экспертов на прощадке";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.Control;
            this.button8.ForeColor = System.Drawing.Color.Black;
            this.button8.Location = new System.Drawing.Point(195, 94);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(383, 23);
            this.button8.TabIndex = 0;
            this.button8.Text = "Ознакомление экспертов с техникой безопасности";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.Control;
            this.button9.ForeColor = System.Drawing.Color.Black;
            this.button9.Location = new System.Drawing.Point(195, 123);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(383, 23);
            this.button9.TabIndex = 0;
            this.button9.Text = "Внесение 30% изменений в задание";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.Control;
            this.button10.ForeColor = System.Drawing.Color.Black;
            this.button10.Location = new System.Drawing.Point(195, 152);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(383, 23);
            this.button10.TabIndex = 0;
            this.button10.Text = "Ознакомление с ведомостями оценки";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.SystemColors.Control;
            this.button11.ForeColor = System.Drawing.Color.Black;
            this.button11.Location = new System.Drawing.Point(195, 181);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(383, 23);
            this.button11.TabIndex = 0;
            this.button11.Text = "Респределение судейскийх ролей";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // Expert
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ListPanel);
            this.Controls.Add(this.ProtocolPanel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.AuCodeTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.SkillLabel);
            this.Controls.Add(this.CempNameLabel);
            this.Controls.Add(this.ProtocolButton);
            this.Controls.Add(this.ExpertsListButton);
            this.Controls.Add(this.PersonListButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Expert";
            this.Text = "Expert";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Expert_FormClosing);
            this.Load += new System.EventHandler(this.Expert_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ListPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ProtocolPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button PersonListButton;
        private System.Windows.Forms.Button ExpertsListButton;
        private System.Windows.Forms.Button ProtocolButton;
        private System.Windows.Forms.Label CempNameLabel;
        private System.Windows.Forms.Label SkillLabel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox AuCodeTextBox;
        private System.Windows.Forms.Panel ListPanel;
        private System.Windows.Forms.Button DeleteButton;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button EditButton;
        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.Button FixListButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel ProtocolPanel;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button7;
    }
}