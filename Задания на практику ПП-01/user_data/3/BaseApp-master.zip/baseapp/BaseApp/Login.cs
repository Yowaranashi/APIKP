﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BaseApp
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = @" Data Source=WM-SQL-SERVER\SQLEXPRESS01;user ID=bsn_user3;Password=PyMZQH;Connect Timeout=30;Encrypt=False;Initial catalog=db_bsn_user3";

                SqlConnection MyConnection = new SqlConnection(connectionString);
                MyConnection.Open();
               



                string ComDel = $" Select count(*) from users where PIN={LoginTextBox.Text} and password ='{PasswordTextBox.Text}' and [ID role] = 6";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                string org = cmd1.ExecuteScalar().ToString();



                ComDel = $" Select count(*) from users where PIN={LoginTextBox.Text} and password ='{PasswordTextBox.Text}' and [ID role] = 2";
                cmd1 = new SqlCommand(ComDel, MyConnection);
                string exp = cmd1.ExecuteScalar().ToString();




                ComDel = $" Select count(*) from users where PIN={LoginTextBox.Text} and password ='{PasswordTextBox.Text}' and [ID role] = 1";
                cmd1 = new SqlCommand(ComDel, MyConnection);
                string person = cmd1.ExecuteScalar().ToString();



            if (Convert.ToInt32(org) != 0)
                {
                    Org main = new Org(connectionString, this);
                    main.ShowDialog();
                }
                else if (Convert.ToInt32(exp) != 0)
                {
                    ComDel = $" Select skill from users where PIN={LoginTextBox.Text} and password ='{PasswordTextBox.Text}' and [ID role] = 2";
                    cmd1 = new SqlCommand(ComDel, MyConnection);
                    string expSkill = cmd1.ExecuteScalar().ToString();


                    Expert expert = new Expert(connectionString, this, expSkill);
                    expert.ShowDialog();
                }
                else if (Convert.ToInt32(person) != 0)
                {
                    ComDel = $" Select skill from users where PIN={LoginTextBox.Text} and password ='{PasswordTextBox.Text}' and [ID role] = 1";
                    cmd1 = new SqlCommand(ComDel, MyConnection);
                    string personSkill = cmd1.ExecuteScalar().ToString();
                    

                    Person personForm = new Person(connectionString, this, personSkill);
                    personForm.ShowDialog();
                }
                else { MessageBox.Show("Отказано в доступе", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Stop); }

                MyConnection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
