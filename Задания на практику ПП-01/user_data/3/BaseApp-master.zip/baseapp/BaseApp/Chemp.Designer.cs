﻿namespace BaseApp
{
    partial class Chemp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MainExpertsDataGridView = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.HelloLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ProtocolButton = new System.Windows.Forms.Button();
            this.ExpertButton = new System.Windows.Forms.Button();
            this.SettingsButton = new System.Windows.Forms.Button();
            this.PersonsButton = new System.Windows.Forms.Button();
            this.ChempNameLabel = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ExpertListPanel = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ShowComboBox = new System.Windows.Forms.ComboBox();
            this.FiltComboBox = new System.Windows.Forms.ComboBox();
            this.SaveButton = new System.Windows.Forms.Button();
            this.ChempSettingsTabControl = new System.Windows.Forms.TabControl();
            this.SettingsTabPage = new System.Windows.Forms.TabPage();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.ProtocolListTabPage = new System.Windows.Forms.TabPage();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.EditButton = new System.Windows.Forms.Button();
            this.AddButton = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Day = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.PersonsRadioButton = new System.Windows.Forms.RadioButton();
            this.ExpertRadioButton = new System.Windows.Forms.RadioButton();
            this.AllRadioButton = new System.Windows.Forms.RadioButton();
            this.SomeListTabPage = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.MainExpertsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.ExpertListPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.ChempSettingsTabControl.SuspendLayout();
            this.SettingsTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.ProtocolListTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SomeListTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.SuspendLayout();
            // 
            // MainExpertsDataGridView
            // 
            this.MainExpertsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MainExpertsDataGridView.Location = new System.Drawing.Point(222, 113);
            this.MainExpertsDataGridView.Name = "MainExpertsDataGridView";
            this.MainExpertsDataGridView.RowHeadersVisible = false;
            this.MainExpertsDataGridView.Size = new System.Drawing.Size(532, 310);
            this.MainExpertsDataGridView.TabIndex = 18;
            this.MainExpertsDataGridView.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(62, 42);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 16;
            this.button1.Text = "Выход";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // HelloLabel
            // 
            this.HelloLabel.AutoSize = true;
            this.HelloLabel.Location = new System.Drawing.Point(25, 113);
            this.HelloLabel.Name = "HelloLabel";
            this.HelloLabel.Size = new System.Drawing.Size(75, 13);
            this.HelloLabel.TabIndex = 15;
            this.HelloLabel.Text = "Добрый день";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(21, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(181, 20);
            this.label1.TabIndex = 14;
            this.label1.Text = "Техническая дирекция";
            // 
            // ProtocolButton
            // 
            this.ProtocolButton.Location = new System.Drawing.Point(43, 354);
            this.ProtocolButton.Name = "ProtocolButton";
            this.ProtocolButton.Size = new System.Drawing.Size(124, 38);
            this.ProtocolButton.TabIndex = 13;
            this.ProtocolButton.Text = "Отчет по сданным протоколам";
            this.ProtocolButton.UseVisualStyleBackColor = true;
            // 
            // ExpertButton
            // 
            this.ExpertButton.Location = new System.Drawing.Point(43, 294);
            this.ExpertButton.Name = "ExpertButton";
            this.ExpertButton.Size = new System.Drawing.Size(124, 38);
            this.ExpertButton.TabIndex = 12;
            this.ExpertButton.Text = "Список главных экспертов";
            this.ExpertButton.UseVisualStyleBackColor = true;
            this.ExpertButton.Click += new System.EventHandler(this.ExpertButton_Click);
            // 
            // SettingsButton
            // 
            this.SettingsButton.Location = new System.Drawing.Point(43, 237);
            this.SettingsButton.Name = "SettingsButton";
            this.SettingsButton.Size = new System.Drawing.Size(124, 38);
            this.SettingsButton.TabIndex = 11;
            this.SettingsButton.Text = "Настройки чемпионата";
            this.SettingsButton.UseVisualStyleBackColor = true;
            this.SettingsButton.Click += new System.EventHandler(this.SettingsButton_Click);
            // 
            // PersonsButton
            // 
            this.PersonsButton.Location = new System.Drawing.Point(43, 177);
            this.PersonsButton.Name = "PersonsButton";
            this.PersonsButton.Size = new System.Drawing.Size(124, 38);
            this.PersonsButton.TabIndex = 10;
            this.PersonsButton.Text = "Список учасников";
            this.PersonsButton.UseVisualStyleBackColor = true;
            this.PersonsButton.Click += new System.EventHandler(this.PersonsButton_Click);
            // 
            // ChempNameLabel
            // 
            this.ChempNameLabel.Location = new System.Drawing.Point(187, 37);
            this.ChempNameLabel.Name = "ChempNameLabel";
            this.ChempNameLabel.Size = new System.Drawing.Size(270, 32);
            this.ChempNameLabel.TabIndex = 19;
            this.ChempNameLabel.Text = "Наименование чемпионата";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(498, 37);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 32);
            this.button2.TabIndex = 20;
            this.button2.Text = "Аналитика";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::BaseApp.Properties.Resources.wsrlogo_01;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(639, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(106, 67);
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // ExpertListPanel
            // 
            this.ExpertListPanel.Controls.Add(this.dataGridView2);
            this.ExpertListPanel.Controls.Add(this.checkBox1);
            this.ExpertListPanel.Controls.Add(this.label3);
            this.ExpertListPanel.Controls.Add(this.label2);
            this.ExpertListPanel.Controls.Add(this.ShowComboBox);
            this.ExpertListPanel.Controls.Add(this.FiltComboBox);
            this.ExpertListPanel.Location = new System.Drawing.Point(222, 113);
            this.ExpertListPanel.Name = "ExpertListPanel";
            this.ExpertListPanel.Size = new System.Drawing.Size(532, 295);
            this.ExpertListPanel.TabIndex = 21;
            this.ExpertListPanel.Visible = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(0, 123);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(532, 195);
            this.dataGridView2.TabIndex = 4;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(298, 74);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(217, 17);
            this.checkBox1.TabIndex = 3;
            this.checkBox1.Text = "Показать только не подтвержденных";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(236, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Показать";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(245, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Фильтр";
            // 
            // ShowComboBox
            // 
            this.ShowComboBox.FormattingEnabled = true;
            this.ShowComboBox.Location = new System.Drawing.Point(298, 47);
            this.ShowComboBox.Name = "ShowComboBox";
            this.ShowComboBox.Size = new System.Drawing.Size(217, 21);
            this.ShowComboBox.TabIndex = 1;
            // 
            // FiltComboBox
            // 
            this.FiltComboBox.FormattingEnabled = true;
            this.FiltComboBox.Location = new System.Drawing.Point(298, 15);
            this.FiltComboBox.Name = "FiltComboBox";
            this.FiltComboBox.Size = new System.Drawing.Size(217, 21);
            this.FiltComboBox.TabIndex = 0;
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(450, 391);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(75, 23);
            this.SaveButton.TabIndex = 5;
            this.SaveButton.Text = "Сохранить";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Visible = false;
            // 
            // ChempSettingsTabControl
            // 
            this.ChempSettingsTabControl.Controls.Add(this.SettingsTabPage);
            this.ChempSettingsTabControl.Controls.Add(this.ProtocolListTabPage);
            this.ChempSettingsTabControl.Controls.Add(this.SomeListTabPage);
            this.ChempSettingsTabControl.Location = new System.Drawing.Point(222, 116);
            this.ChempSettingsTabControl.Name = "ChempSettingsTabControl";
            this.ChempSettingsTabControl.SelectedIndex = 0;
            this.ChempSettingsTabControl.Size = new System.Drawing.Size(532, 262);
            this.ChempSettingsTabControl.TabIndex = 5;
            this.ChempSettingsTabControl.Visible = false;
            // 
            // SettingsTabPage
            // 
            this.SettingsTabPage.Controls.Add(this.checkBox3);
            this.SettingsTabPage.Controls.Add(this.checkBox2);
            this.SettingsTabPage.Controls.Add(this.label4);
            this.SettingsTabPage.Controls.Add(this.pictureBox2);
            this.SettingsTabPage.Location = new System.Drawing.Point(4, 22);
            this.SettingsTabPage.Name = "SettingsTabPage";
            this.SettingsTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.SettingsTabPage.Size = new System.Drawing.Size(524, 236);
            this.SettingsTabPage.TabIndex = 0;
            this.SettingsTabPage.Text = "Основные настройки";
            this.SettingsTabPage.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(16, 165);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(330, 17);
            this.checkBox3.TabIndex = 20;
            this.checkBox3.Text = "Зам главного эксперта может принимать участие в оценке";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Checked = true;
            this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox2.Location = new System.Drawing.Point(16, 137);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(298, 17);
            this.checkBox2.TabIndex = 20;
            this.checkBox2.Text = "Главный эксперт может принимать участие в оценке";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(320, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "Логотип";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::BaseApp.Properties.Resources.wsrlogo_01;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(396, 56);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(115, 86);
            this.pictureBox2.TabIndex = 18;
            this.pictureBox2.TabStop = false;
            // 
            // ProtocolListTabPage
            // 
            this.ProtocolListTabPage.Controls.Add(this.DeleteButton);
            this.ProtocolListTabPage.Controls.Add(this.EditButton);
            this.ProtocolListTabPage.Controls.Add(this.AddButton);
            this.ProtocolListTabPage.Controls.Add(this.dataGridView3);
            this.ProtocolListTabPage.Controls.Add(this.label5);
            this.ProtocolListTabPage.Controls.Add(this.comboBox1);
            this.ProtocolListTabPage.Controls.Add(this.groupBox1);
            this.ProtocolListTabPage.Location = new System.Drawing.Point(4, 22);
            this.ProtocolListTabPage.Name = "ProtocolListTabPage";
            this.ProtocolListTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.ProtocolListTabPage.Size = new System.Drawing.Size(524, 236);
            this.ProtocolListTabPage.TabIndex = 1;
            this.ProtocolListTabPage.Text = "Список протоколов";
            this.ProtocolListTabPage.UseVisualStyleBackColor = true;
            // 
            // DeleteButton
            // 
            this.DeleteButton.Location = new System.Drawing.Point(382, 193);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(90, 30);
            this.DeleteButton.TabIndex = 4;
            this.DeleteButton.Text = "Удалить";
            this.DeleteButton.UseVisualStyleBackColor = true;
            // 
            // EditButton
            // 
            this.EditButton.Location = new System.Drawing.Point(113, 193);
            this.EditButton.Name = "EditButton";
            this.EditButton.Size = new System.Drawing.Size(90, 30);
            this.EditButton.TabIndex = 4;
            this.EditButton.Text = "Изменить";
            this.EditButton.UseVisualStyleBackColor = true;
            // 
            // AddButton
            // 
            this.AddButton.Location = new System.Drawing.Point(17, 193);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(90, 30);
            this.AddButton.TabIndex = 4;
            this.AddButton.Text = "Добавить";
            this.AddButton.UseVisualStyleBackColor = true;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.name,
            this.Day});
            this.dataGridView3.Location = new System.Drawing.Point(8, 101);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersVisible = false;
            this.dataGridView3.Size = new System.Drawing.Size(495, 79);
            this.dataGridView3.TabIndex = 3;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "";
            this.Column1.Name = "Column1";
            // 
            // name
            // 
            this.name.HeaderText = "Наименование";
            this.name.Name = "name";
            this.name.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.name.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.name.Width = 250;
            // 
            // Day
            // 
            this.Day.HeaderText = "День чемпионата";
            this.Day.Name = "Day";
            this.Day.Width = 140;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(270, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "День чемпионата";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "c-1",
            "c-2",
            "c-3",
            "c+1"});
            this.comboBox1.Location = new System.Drawing.Point(382, 75);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.PersonsRadioButton);
            this.groupBox1.Controls.Add(this.ExpertRadioButton);
            this.groupBox1.Controls.Add(this.AllRadioButton);
            this.groupBox1.Location = new System.Drawing.Point(157, 20);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(346, 43);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Протоколы для";
            // 
            // PersonsRadioButton
            // 
            this.PersonsRadioButton.AutoSize = true;
            this.PersonsRadioButton.Location = new System.Drawing.Point(121, 16);
            this.PersonsRadioButton.Name = "PersonsRadioButton";
            this.PersonsRadioButton.Size = new System.Drawing.Size(74, 17);
            this.PersonsRadioButton.TabIndex = 0;
            this.PersonsRadioButton.TabStop = true;
            this.PersonsRadioButton.Text = "Учеников";
            this.PersonsRadioButton.UseVisualStyleBackColor = true;
            // 
            // ExpertRadioButton
            // 
            this.ExpertRadioButton.AutoSize = true;
            this.ExpertRadioButton.Location = new System.Drawing.Point(206, 16);
            this.ExpertRadioButton.Name = "ExpertRadioButton";
            this.ExpertRadioButton.Size = new System.Drawing.Size(79, 17);
            this.ExpertRadioButton.TabIndex = 0;
            this.ExpertRadioButton.TabStop = true;
            this.ExpertRadioButton.Text = "Экспертов";
            this.ExpertRadioButton.UseVisualStyleBackColor = true;
            // 
            // AllRadioButton
            // 
            this.AllRadioButton.AutoSize = true;
            this.AllRadioButton.Location = new System.Drawing.Point(291, 16);
            this.AllRadioButton.Name = "AllRadioButton";
            this.AllRadioButton.Size = new System.Drawing.Size(49, 17);
            this.AllRadioButton.TabIndex = 0;
            this.AllRadioButton.TabStop = true;
            this.AllRadioButton.Text = "Всех";
            this.AllRadioButton.UseVisualStyleBackColor = true;
            // 
            // SomeListTabPage
            // 
            this.SomeListTabPage.Controls.Add(this.button3);
            this.SomeListTabPage.Controls.Add(this.button4);
            this.SomeListTabPage.Controls.Add(this.button5);
            this.SomeListTabPage.Controls.Add(this.dataGridView4);
            this.SomeListTabPage.Location = new System.Drawing.Point(4, 22);
            this.SomeListTabPage.Name = "SomeListTabPage";
            this.SomeListTabPage.Size = new System.Drawing.Size(524, 236);
            this.SomeListTabPage.TabIndex = 2;
            this.SomeListTabPage.Text = "Список особых полономочий экспертов";
            this.SomeListTabPage.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(377, 193);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(90, 30);
            this.button3.TabIndex = 6;
            this.button3.Text = "Удалить";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(108, 193);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(90, 30);
            this.button4.TabIndex = 7;
            this.button4.Text = "Изменить";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(12, 193);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(90, 30);
            this.button5.TabIndex = 8;
            this.button5.Text = "Добавить";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewCheckBoxColumn1,
            this.dataGridViewTextBoxColumn1,
            this.Column3,
            this.dataGridViewTextBoxColumn2,
            this.Column2});
            this.dataGridView4.Location = new System.Drawing.Point(3, 20);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersVisible = false;
            this.dataGridView4.Size = new System.Drawing.Size(495, 160);
            this.dataGridView4.TabIndex = 5;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.HeaderText = "№";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewCheckBoxColumn1.Width = 25;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Роль эксперта (особые полномочия)";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 160;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Описание";
            this.Column3.Name = "Column3";
            this.Column3.Width = 107;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Мин. кол-во экспертов";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Маск. кол-во экспертов";
            this.Column2.Name = "Column2";
            // 
            // Chemp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(773, 444);
            this.Controls.Add(this.ChempSettingsTabControl);
            this.Controls.Add(this.MainExpertsDataGridView);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.ChempNameLabel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.HelloLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ProtocolButton);
            this.Controls.Add(this.ExpertButton);
            this.Controls.Add(this.SettingsButton);
            this.Controls.Add(this.PersonsButton);
            this.Controls.Add(this.ExpertListPanel);
            this.Controls.Add(this.SaveButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Chemp";
            this.Text = "Chemp";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Chemp_FormClosing);
            this.Load += new System.EventHandler(this.Chemp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MainExpertsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ExpertListPanel.ResumeLayout(false);
            this.ExpertListPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ChempSettingsTabControl.ResumeLayout(false);
            this.SettingsTabPage.ResumeLayout(false);
            this.SettingsTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ProtocolListTabPage.ResumeLayout(false);
            this.ProtocolListTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.SomeListTabPage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView MainExpertsDataGridView;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label HelloLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ProtocolButton;
        private System.Windows.Forms.Button ExpertButton;
        private System.Windows.Forms.Button SettingsButton;
        private System.Windows.Forms.Button PersonsButton;
        private System.Windows.Forms.Label ChempNameLabel;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel ExpertListPanel;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox ShowComboBox;
        private System.Windows.Forms.ComboBox FiltComboBox;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.TabControl ChempSettingsTabControl;
        private System.Windows.Forms.TabPage SettingsTabPage;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TabPage ProtocolListTabPage;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton PersonsRadioButton;
        private System.Windows.Forms.RadioButton ExpertRadioButton;
        private System.Windows.Forms.RadioButton AllRadioButton;
        private System.Windows.Forms.TabPage SomeListTabPage;
        private System.Windows.Forms.Button DeleteButton;
        private System.Windows.Forms.Button EditButton;
        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Day;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
    }
}