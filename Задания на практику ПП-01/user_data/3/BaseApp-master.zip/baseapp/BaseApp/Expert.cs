﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BaseApp
{
    public partial class Expert : Form
    {
        public Expert(string connectionString, Login login, string skill)
        {
            InitializeComponent();
            _connectionString = connectionString;
            this._login = login;
            _skill = skill;
        }

        private string _connectionString;
        private Login _login;
        private SqlConnection MyConnection;
        private int _chempID;
        private string _skill;


        private void Expert_Load(object sender, EventArgs e)
        {

            try
            {
                MyConnection = new SqlConnection(_connectionString);
                MyConnection.Open();

                ChempNameInit();

                SkillInit();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        private void SkillInit()
        {
            try
            {
                string ComDel = $"select title from skill where id = {_skill}";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);


                SkillLabel.Text = "Компетенция: " + cmd1.ExecuteScalar().ToString();

            }
            catch { }
        }

        private void ChempNameInit()
        {
            string ComDel = $"select title, id date_start from competition where date_start > (GETDATE() - day(30)) " +
                            $"order by date_start";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);

            var result = new List<string>();
            var chemps = new List<string>();


            var Reader = cmd1.ExecuteReader();
            while (Reader.Read())
            {
                result.Add(Reader[0].ToString());
                chemps.Add(Reader[1].ToString());
            }

            try
            {
                CempNameLabel.Text = result[result.Count - 1];
                _chempID = Convert.ToInt32(chemps[chemps.Count - 1]);
            }
            catch (Exception)
            {
                MessageBox.Show("Нет ближайших чемпионатов", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                _exitFlag = true;
                this.Close();
            }
            Reader.Close();
        }


        private bool _exitFlag = false;

        private void Expert_FormClosing(object sender, FormClosingEventArgs e)
        {          
            MyConnection.Close();
            if (!_exitFlag)
            {
                _login.Close(); 
            }
        }


        private void DataClear()
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();
        }


        private void PersonListButton_Click(object sender, EventArgs e)
        {
            ListPanel.Visible = true;
            ProtocolPanel.Visible = false;

            try
            {
                DataClear();

                dataGridView1.ColumnCount = 7;
                dataGridView1.Columns[0].Name = "№";
                dataGridView1.Columns[1].Name = "Фамилия";
                dataGridView1.Columns[2].Name = "Имя";
                dataGridView1.Columns[3].Name = "Отчество";
                dataGridView1.Columns[4].Name = "Дата рождения";
                dataGridView1.Columns[5].Name = "Полных лет";
                dataGridView1.Columns[6].Name = "Статус подтверждения";
                dataGridView1.RowCount = 1;



                string ComDel = $"select id, fio, [Дата рождения], [статус подтверждения] from users where чемпионат = {_chempID} and skill = {_skill}";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);

                var Reader = cmd1.ExecuteReader();


                while (Reader.Read())
                {
                    string id = Reader[0].ToString();
                    string firstName = Reader[1].ToString().Split(' ')[0];
                    string lastName = Reader[1].ToString().Split(' ')[1];
                    string middleName = Reader[1].ToString().Split(' ')[2];
                    string date = Reader[2].ToString();
                    TimeSpan delt = DateTime.Now - DateTime.Parse(date);

                    string status = Reader[3].ToString();


                    dataGridView1.Rows.Add(id, firstName, lastName, middleName, date, (int)delt.Days / 365, status);
                }
                Reader.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void ExpertsListButton_Click(object sender, EventArgs e)
        {
            ListPanel.Visible = true;
            ProtocolPanel.Visible = false;

            try
            {
                DataClear();

                dataGridView1.ColumnCount = 6;
                dataGridView1.Columns[0].Name = "№";
                dataGridView1.Columns[1].Name = "Фамилия";
                dataGridView1.Columns[2].Name = "Имя";
                dataGridView1.Columns[3].Name = "Отчество";
                dataGridView1.Columns[4].Name = "ФИО учасника";
                dataGridView1.Columns[5].Name = "Статус подтверждения";
                dataGridView1.RowCount = 1;



                string ComDel = $"select id, fio, [статус подтверждения] from users where чемпионат = {_chempID} and [id role] = 2 and skill = {_skill}";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);

                var Reader = cmd1.ExecuteReader();


                while (Reader.Read())
                {
                    string id = Reader[0].ToString();
                    string firstName = Reader[1].ToString().Split(' ')[0];
                    string lastName = Reader[1].ToString().Split(' ')[1];
                    string middleName = Reader[1].ToString().Split(' ')[2];

                    string status = Reader[2].ToString();


                    dataGridView1.Rows.Add(id, firstName, lastName, middleName, status);
                }
                Reader.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            _exitFlag = true;
            this.Close();
        }


        private void ProtocolButton_Click(object sender, EventArgs e)
        {
            ListPanel.Visible = false;
            ProtocolPanel.Visible = true;
        }
    }
}
